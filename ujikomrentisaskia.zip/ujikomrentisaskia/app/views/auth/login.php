<div class="main-content">

    <div class="login-wrapper">

        <div class="card login-card">

            <h2 style="text-align:center; margin-bottom:20px;">
                <i class="bi bi-shield-lock"></i>
                Login Sistem Parkir
            </h2>

            <?php if(isset($error)): ?>
                <div class="alert alert-error">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="index.php?url=auth/login">

                <label>
                    <i class="bi bi-person"></i> Username
                </label>
                <input type="text" name="username" required>

                <label>
                    <i class="bi bi-lock"></i> Password
                </label>
                <input type="password" name="password" required>

                <button class="btn-gradient" style="width:100%;">
                    <i class="bi bi-box-arrow-in-right"></i>
                    Login
                </button>

            </form>

        </div>

    </div>

</div>