<div class="main-content">

    <div class="content-box">

        <h3>Konfirmasi Kendaraan Keluar</h3>

        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success'];
                unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error'];
                unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($transaksi) && !empty($kendaraan)): ?>

            <div class="content-box" style="margin-top:20px;">

                <p><strong>Plat Nomor :</strong> <?= htmlspecialchars($kendaraan['plat_nomor']); ?></p>

                <p><strong>Jenis Kendaraan :</strong> <?= ucfirst($kendaraan['jenis_kendaraan']); ?></p>

                <p><strong>Area Parkir :</strong> <?= $transaksi['nama_area'] ?? '-'; ?></p>

                <p><strong>Waktu Check-In :</strong> <?= $transaksi['checkin_time']; ?></p>

                <form action="?url=transaksi/simpanKeluar" method="POST">

                    <input type="hidden" name="id" value="<?= $transaksi['id']; ?>">

                    <button type="submit" class="btn btn-gradient">
                        Proses Check-Out
                    </button>

                    <a href="?url=transaksi/riwayat" class="btn btn-gradient">
                        Kembali
                    </a>

                </form>

            </div>

        <?php else: ?>

            <p style="margin-top:20px;">Data kendaraan tidak ditemukan.</p>

        <?php endif; ?>

    </div>

</div>