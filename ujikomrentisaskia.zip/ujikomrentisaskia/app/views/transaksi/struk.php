<div style="display:flex; justify-content:center; padding:20px;">
    <div style="
        max-width:400px;
        width:100%;
        background-color:#FFFFFF;
        color:#000000;
        padding:20px;
        border:1px solid #333;
        border-radius:8px;
        font-family:monospace;
        text-align:center;
        box-shadow:0 2px 6px rgba(0,0,0,0.2);
    ">
        <h3 style="margin-bottom:5px;">STRUK PARKIR</h3>
        <p style="margin-top:0;">Sistem Parkir Rajendra UJIKOM</p>
        <hr>

        <p><strong>Informasi Kendaraan</strong></p>
        <p>Plat Nomor : <?= htmlspecialchars($kendaraan['plat_nomor']); ?></p>
        <p>Jenis : <?= ucfirst($kendaraan['jenis_kendaraan']); ?></p>
        <p>Area Parkir : <?= htmlspecialchars($area['nama_area']); ?></p>

        <hr>

        <p><strong>Waktu Parkir</strong></p>
        <p>Check-In : <?= date('d-m-Y H:i:s', strtotime($transaksi['checkin_time'])); ?></p>
        <p>Check-Out : <?= date('d-m-Y H:i:s', strtotime($transaksi['checkout_time'])); ?></p>
        <?php
        $jam = floor($transaksi['duration'] / 60);
        $menit = $transaksi['duration'] % 60;
        ?>
        <p>Durasi : <?= ($jam > 0 ? $jam . " Jam " : "") . $menit . " Menit"; ?></p>

        <hr>

        <p><strong>Rincian Biaya</strong></p>
        <p>Tarif : Rp <?= number_format($transaksi['tarif_per_jam']); ?> / jam</p>
        <p>Total : <strong>Rp <?= number_format($transaksi['fee']); ?></strong></p>

        <hr>

        <p>Petugas : <?= htmlspecialchars($_SESSION['user']['nama_lengkap']); ?></p>
        <p>Tanggal Cetak : <?= date('d-m-Y H:i:s'); ?></p>

        <hr>

        <p style="margin-bottom:0;">
            Terima Kasih<br>
            Selamat Jalan
        </p>
    </div>
</div>