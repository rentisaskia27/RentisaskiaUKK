<div class="main-content">

    <div class="content-box">

        <h3>Daftar Kendaraan Menunggu Pembayaran</h3>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success'];
                unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error'];
                unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <p>
            Total kendaraan menunggu pembayaran:
            <strong><?= count($transaksi); ?></strong>
        </p>

        <table class="table-gradient">

            <thead>
                <tr>
                    <th>No</th>
                    <th>Plat Nomor</th>
                    <th>Jenis</th>
                    <th>Area</th>
                    <th>Check-In</th>
                    <th>Check-Out</th>
                    <th>Durasi</th>
                    <th>Biaya</th>
                    <th>Status</th>
                    <th width="200">Aksi</th>
                </tr>
            </thead>

            <tbody>

                <?php if (!empty($transaksi)): ?>

                    <?php $no = 1;
                    foreach ($transaksi as $t): ?>

                        <tr>

                            <td><?= $no++; ?></td>

                            <td><?= htmlspecialchars($t['plat_nomor']); ?></td>

                            <td><?= ucfirst($t['jenis_kendaraan']); ?></td>

                            <td><?= htmlspecialchars($t['nama_area']); ?></td>

                            <td>
                                <?= date('d M Y H:i', strtotime($t['checkin_time'])); ?>
                            </td>

                            <td>
                                <?= date('d M Y H:i', strtotime($t['checkout_time'])); ?>
                            </td>

                            <td>
                                <?php
                                $jam = floor($t['duration'] / 60);
                                $menit = $t['duration'] % 60;
                                echo $jam . " Jam " . $menit . " Menit";
                                ?>
                            </td>

                            <td>
                                Rp <?= number_format($t['fee'], 0, ',', '.'); ?>
                            </td>

                            <td>
                                <span class="badge-warning">
                                    Menunggu Pembayaran
                                </span>
                            </td>

                            <td>

                                <a href="?url=transaksi/konfirmasi/<?= $t['id']; ?>"
                                    class="btn btn-gradient me-3"
                                    onclick="return confirm('Pembayaran diterima dan buka palang?')">
                                    Buka Palang
                                </a>

                               
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="10" style="text-align:center;">
                            Belum ada kendaraan menunggu pembayaran
                        </td>
                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>