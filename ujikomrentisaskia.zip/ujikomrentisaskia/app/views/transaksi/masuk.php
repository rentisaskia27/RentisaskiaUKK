<div class="main-content">

    <div class="content-box">

        <h3>Kendaraan Masuk (Check-In)</h3>

        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success'];
                unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error'];
                unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <form action="?url=transaksi/simpanMasuk" method="POST">

            <!-- Pencarian Plat -->
            <div class="mb-3">
                <label>Cari Plat Nomor</label>
                <input
                    type="text"
                    id="searchPlat"
                    placeholder="Ketik plat nomor..."
                    class="form-input">
            </div>

            <!-- Kendaraan -->
            <div class="mb-3">
                <label>Pilih Kendaraan</label>
                <select name="kendaraan_id" id="kendaraanSelect" required class="form-input">
                    <option value="">-- Pilih Kendaraan --</option>
                    <?php foreach ($kendaraan as $k): ?>
                        <option value="<?= $k['id']; ?>">
                            <?= $k['plat_nomor']; ?> | <?= ucfirst($k['jenis_kendaraan']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Area -->
            <div class="mb-3">
                <label>Pilih Area Parkir</label>
                <select name="area_id" required class="form-input">
                    <option value="">-- Pilih Area --</option>
                    <?php foreach ($area as $a): ?>
                        <?php $penuh = $a['terisi'] >= $a['kapasitas']; ?>
                        <option
                            value="<?= $a['id']; ?>"
                            <?= $penuh ? 'disabled' : ''; ?>>
                            <?= $a['nama_area']; ?>
                            (<?= $a['terisi']; ?>/<?= $a['kapasitas']; ?> terisi)
                            <?= $penuh ? ' - PENUH' : ''; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Petugas -->
            <div class="mb-3">
                <label>Petugas</label>
                <input
                    type="text"
                    value="<?= $_SESSION['user']['nama_lengkap']; ?>"
                    readonly
                    class="form-input">
                <input
                    type="hidden"
                    name="petugas_id"
                    value="<?= $_SESSION['user']['id']; ?>">
            </div>

            <button type="submit" class="btn btn-gradient">
                Check-In
            </button>

            <a href="?url=transaksi/riwayat" class="btn btn-gradient">
                Batal
            </a>

        </form>

    </div>

</div>
<!-- END MAIN CONTENT -->

<script>
    document.getElementById('searchPlat').addEventListener('keyup', function() {
        let keyword = this.value.toLowerCase();
        let options = document.querySelectorAll('#kendaraanSelect option');
        options.forEach(function(opt) {
            let text = opt.text.toLowerCase();
            if (text.includes(keyword) || opt.value === "") {
                opt.style.display = "block";
            } else {
                opt.style.display = "none";
            }
        });
    });
</script>