<div class="main-content">

    <div class="content-box">

        <h2>Riwayat Transaksi Parkir</h2>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error'];
                unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success'];
                unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['user']['role'] == 'petugas'): ?>
            <a href="?url=transaksi/masuk" class="btn btn-gradient mb-2">
                Check-In Kendaraan
            </a>
        <?php endif; ?>

        <?php if (!empty($transaksi)): ?>

            <table class="table-gradient">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Plat Nomor</th>
                        <th>Jenis</th>
                        <th>Area</th>
                        <th>Petugas</th>
                        <th>Check-In</th>
                        <th>Check-Out</th>
                        <th>Durasi</th>
                        <th>Biaya</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php
                    $no = $startNumber;
                    $total = 0;
                    foreach ($transaksi as $t):
                        if (isset($t['fee'])) {
                            $total += $t['fee'];
                        }
                    ?>

                        <tr>

                            <td><?= $no++; ?></td>
                            <td><?= htmlspecialchars($t['plat_nomor']); ?></td>
                            <td><?= ucfirst($t['jenis_kendaraan']); ?></td>
                            <td><?= htmlspecialchars($t['nama_area']); ?></td>
                            <td><?= htmlspecialchars($t['petugas']); ?></td>
                            <td><?= date('d M Y H:i', strtotime($t['checkin_time'])); ?></td>
                            <td><?= !empty($t['checkout_time']) ? date('d M Y H:i', strtotime($t['checkout_time'])) : '-' ?></td>
                            <td>
                                <?php
                                if (isset($t['duration'])) {
                                    $jam = floor($t['duration'] / 60);
                                    $menit = $t['duration'] % 60;
                                    echo $jam . " Jam " . $menit . " Menit";
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td><?= isset($t['fee']) ? 'Rp ' . number_format($t['fee'], 0, ',', '.') : '-' ?></td>
                            <td>
                                <?php if ($t['status'] == 'IN'): ?>
                                    <span class="badge-success">Sedang Parkir</span>
                                <?php elseif ($t['status'] == 'OUT'): ?>
                                    <span class="badge-warning">Menunggu Pembayaran</span>
                                <?php else: ?>
                                    <span class="badge-primary">Selesai</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($_SESSION['user']['role'] == 'petugas' && $t['status'] == 'IN'): ?>
                                    <a href="?url=transaksi/keluar/<?= $t['kendaraan_id']; ?>"
                                        class="btn btn-gradient">
                                        Check-Out
                                    </a>
                                <?php endif; ?>

                               
                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

                <?php if ($_SESSION['user']['role'] == 'owner'): ?>
                    <tfoot>
                        <tr>
                            <th colspan="8">TOTAL PENDAPATAN</th>
                            <th colspan="3">Rp <?= number_format($total, 0, ',', '.'); ?></th>
                        </tr>
                    </tfoot>
                <?php endif; ?>

            </table>

            <div class="pagination">

                <?php if ($currentPage > 1): ?>
                    <a href="?url=transaksi/riwayat&page=<?= $currentPage - 1; ?>">
                        Prev
                    </a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPage; $i++): ?>

                    <a href="?url=transaksi/riwayat&page=<?= $i; ?>"
                        class="<?= $i == $currentPage ? 'active' : ''; ?>">
                        <?= $i; ?>
                    </a>

                <?php endfor; ?>

                <?php if ($currentPage < $totalPage): ?>
                    <a href="?url=transaksi/riwayat&page=<?= $currentPage + 1; ?>">
                        Next
                    </a>
                <?php endif; ?>

            </div>

        <?php else: ?>
            <div class="alert alert-info">
                Belum ada transaksi
            </div>
        <?php endif; ?>

    </div>

</div>