<div class="main-content">

    <div class="content-box">

        <h3><?= isset($tarif) ? 'Edit Tarif' : 'Tambah Tarif'; ?></h3>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form action="<?= isset($tarif) ? '?url=tarif/update' : '?url=tarif/simpan'; ?>" method="POST">

            <?php if (isset($tarif)): ?>
                <input type="hidden" name="id" value="<?= $tarif['id']; ?>">
            <?php endif; ?>

            <div class="mb-3">
                <label>Jenis Kendaraan</label>
                <select name="jenis_kendaraan" required class="input-gradient">
                    <option value="">-- Pilih --</option>
                    <?php
                    $semua = ['motor', 'mobil'];
                    foreach ($semua as $j) :
                        $selected = (isset($tarif) && $tarif['jenis_kendaraan'] == $j) ? 'selected' : '';
                    ?>
                        <option value="<?= $j; ?>" <?= $selected; ?>><?= ucfirst($j); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Tarif per Jam</label>
                <input
                    type="number"
                    name="tarif_per_jam"
                    value="<?= $tarif['tarif_per_jam'] ?? ''; ?>"
                    required
                    class="input-gradient">
            </div>

            <button class="btn btn-gradient">
                <i class="bi bi-save"></i> <?= isset($tarif) ? 'Update' : 'Simpan'; ?>
            </button>
            <a href="?url=tarif/index" class="btn btn-gradient">
                <i class="bi bi-arrow-left-circle"></i> Kembali
            </a>

        </form>

    </div>

</div>