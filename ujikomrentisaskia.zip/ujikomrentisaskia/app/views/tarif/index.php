<div class="main-content">

    <div class="content-box">

        <h3>Data Tarif</h3>

        <!-- alert success -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success']; ?>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <!-- alert error -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- tombol tambah -->
        <a href="?url=tarif/tambah" class="btn btn-gradient mb-3">
            <i class="bi bi-plus-circle"></i> Tambah Tarif
        </a>

        <!-- tabel tarif -->
        <table class="table-gradient">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis Kendaraan</th>
                    <th>Tarif per Jam</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($tarif as $t): ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $t['jenis_kendaraan']; ?></td>
                        <td>
                            Rp <?= number_format($t['tarif_per_jam'], 0, ',', '.'); ?>
                        </td>
                        <td>
                            <a href="?url=tarif/edit/<?= $t['id']; ?>" class="btn btn-gradient">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <a href="?url=tarif/hapus/<?= $t['id']; ?>" class="btn btn-gradient" onclick="return confirm('Yakin hapus?')">
                                <i class="bi bi-trash"></i> Hapus
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div>

</div>