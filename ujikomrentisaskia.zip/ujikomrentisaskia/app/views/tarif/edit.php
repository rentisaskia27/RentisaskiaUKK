<div class="main-content">

    <div class="content-box">

        <h3>Edit Tarif</h3>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form action="?url=tarif/update" method="POST">

            <input type="hidden" name="id" value="<?= $tarif['id']; ?>">

            <div class="mb-3">
                <label>Jenis Kendaraan</label>
                <select name="jenis_kendaraan" required class="input-gradient">
                    <?php
                    $semua = ['motor', 'mobil'];
                    foreach ($semua as $j) {
                        $selected = ($tarif['jenis_kendaraan'] == $j) ? 'selected' : '';
                        echo "<option value='$j' $selected>" . ucfirst($j) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Tarif per Jam</label>
                <input
                    type="number"
                    name="tarif_per_jam"
                    value="<?= $tarif['tarif_per_jam']; ?>"
                    required
                    class="input-gradient">
            </div>

            <button type="submit" class="btn btn-gradient">
                <i class="bi bi-save"></i> Update
            </button>
            <a href="?url=tarif/index" class="btn btn-gradient">
                <i class="bi bi-arrow-left-circle"></i> Kembali
            </a>

        </form>

    </div>

</div>