<div class="main-content">

    <div class="content-box">

        <h3>Edit Kendaraan</h3>

        <!-- Alert Error -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
        <?php unset($_SESSION['error']); endif; ?>

        <form action="?url=kendaraan/update" method="POST">

            <input type="hidden" name="id" value="<?= $kendaraan['id']; ?>">

            <div class="mb-3">
                <label>Card ID RFID</label>
                <input
                    type="text"
                    name="card_id"
                    value="<?= $kendaraan['card_id']; ?>"
                    required
                    class="input-gradient">
            </div>

            <div class="mb-3">
                <label>Plat Nomor</label>
                <input
                    type="text"
                    name="plat_nomor"
                    value="<?= $kendaraan['plat_nomor']; ?>"
                    required
                    class="input-gradient">
            </div>

            <div class="mb-3">
                <label>Tarif Kendaraan</label>
                <select name="tarif_id" required class="input-gradient">
                    <option value="">-- Pilih --</option>
                    <?php foreach ($tarif as $t): ?>
                        <option
                            value="<?= $t['id']; ?>"
                            <?= ($kendaraan['tarif_id'] == $t['id']) ? 'selected' : ''; ?>>
                            <?= $t['jenis_kendaraan']; ?>
                            - Rp <?= number_format($t['tarif_per_jam'], 0, ',', '.'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="btn btn-gradient">
                <i class="bi bi-save"></i> Update
            </button>
            <a href="?url=kendaraan/index" class="btn btn-gradient">
                <i class="bi bi-arrow-left-circle"></i> Kembali
            </a>

        </form>

    </div>

</div>