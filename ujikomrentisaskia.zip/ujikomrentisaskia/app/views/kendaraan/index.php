<?php require_once '../app/views/layouts/header.php'; ?>

<div class="main-content">
    <div class="content-box">

        <h3>Data Kendaraan</h3>

        <!-- Tambah Kendaraan -->
        <a href="?url=kendaraan/tambah" class="btn btn-gradient mb-3">
            <i class="bi bi-plus-circle"></i> Tambah Kendaraan
        </a>

        <!-- Alert Success -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success']; ?>
            </div>
        <?php unset($_SESSION['success']); endif; ?>

        <!-- Alert Error -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
        <?php unset($_SESSION['error']); endif; ?>

        <!-- Tabel Kendaraan -->
        <table class="table-gradient">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Card ID</th>
                    <th>Plat Nomor</th>
                    <th>Jenis Tarif</th>
                    <th>Tarif per Jam</th>
                    <th>Status Tarif</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php
                $no = 1;
                if (!empty($kendaraan)) :
                    foreach ($kendaraan as $k) :
                ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $k['card_id']; ?></td>
                        <td><?= $k['plat_nomor']; ?></td>
                        <td><?= htmlspecialchars($k['jenis_tarif']); ?></td>
                        <td>
                            <?= isset($k['tarif_per_jam'])
                                ? 'Rp ' . number_format($k['tarif_per_jam'], 0, ',', '.')
                                : '-'; ?>
                        </td>
                        <td>
                            <?= isset($k['status_aktif']) && $k['status_aktif'] == 1
                                ? '<span class="badge-active">Aktif</span>'
                                : '<span class="badge-nonaktif">Nonaktif</span>'; ?>
                        </td>
                        <td>
                            <a href="?url=kendaraan/edit/<?= $k['id']; ?>" class="btn btn-gradient">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <a href="?url=kendaraan/hapus/<?= $k['id']; ?>" class="btn btn-gradient" onclick="return confirm('Yakin hapus?')">
                                <i class="bi bi-trash"></i> Hapus
                            </a>
                        </td>
                    </tr>
                <?php
                    endforeach;
                endif;
                ?>
            </tbody>
        </table>

    </div>
</div>

<?php require_once '../app/views/layouts/footer.php'; ?>