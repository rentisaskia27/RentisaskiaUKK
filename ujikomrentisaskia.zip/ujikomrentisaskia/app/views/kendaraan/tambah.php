<div class="main-content">

    <div class="content-box">

        <h3>Tambah Kendaraan</h3>

        <!-- Alert Error -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form action="?url=kendaraan/simpan" method="POST">

            <div class="mb-3">
                <label>Card ID RFID</label>
                <input type="text" name="card_id" required class="input-gradient">
            </div>

            <div class="mb-3">
                <label>Plat Nomor</label>
                <input type="text" name="plat_nomor" required class="input-gradient">
            </div>

            <div class="mb-3">
                <label>Tarif Kendaraan</label>
                <select name="tarif_id" required onchange="setJenis(this)" class="input-gradient">
                    <option value="">-- Pilih Tarif --</option>
                    <?php foreach ($tarif as $t): ?>
                        <option 
                            value="<?= $t['id']; ?>"
                            data-jenis="<?= $t['jenis_kendaraan']; ?>">
                            <?= $t['jenis_kendaraan'] . " - Rp" . number_format($t['tarif_per_jam'], 0, ',', '.'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <input type="hidden" name="jenis_kendaraan" id="jenis_kendaraan">

            <button type="submit" class="btn btn-gradient">
                <i class="bi bi-save"></i> Simpan
            </button>
            <a href="?url=kendaraan/index" class="btn btn-gradient">
                <i class="bi bi-arrow-left-circle"></i> Kembali
            </a>

        </form>

    </div>

</div>

<script>
function setJenis(select) {
    var jenis = select.options[select.selectedIndex].getAttribute('data-jenis');
    document.getElementById('jenis_kendaraan').value = jenis;
}
</script>