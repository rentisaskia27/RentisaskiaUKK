<div class="main-content">

    <div class="content-box">

        <h3>Edit Area Parkir</h3>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="bi bi-exclamation-triangle"></i> <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form action="?url=area/update" method="POST">

            <input type="hidden" name="id" value="<?= $area['id']; ?>">

            <div class="mb-3">
                <label>Nama Area</label>
                <input 
                    type="text" 
                    name="nama_area" 
                    class="input-gradient"
                    value="<?= $area['nama_area']; ?>" 
                    required>
            </div>

            <div class="mb-3">
                <label>Kapasitas</label>
                <input 
                    type="number" 
                    name="kapasitas" 
                    class="input-gradient"
                    value="<?= $area['kapasitas']; ?>" 
                    required>
            </div>

            <div class="mb-3">
                <label>Terisi</label>
                <input 
                    type="number" 
                    name="terisi" 
                    class="input-gradient"
                    value="<?= $area['terisi']; ?>" 
                    readonly>
            </div>

            <button class="btn btn-gradient">
                <i class="bi bi-pencil-square"></i> Update
            </button>
            <a href="?url=area/index" class="btn btn-gradient">
                <i class="bi bi-arrow-left-circle"></i> Kembali
            </a>

        </form>

    </div>

</div>