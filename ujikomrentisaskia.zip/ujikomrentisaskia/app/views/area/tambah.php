<div class="main-content">

    <div class="content-box">

        <h3>Tambah Area Parkir</h3>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="bi bi-exclamation-triangle"></i> <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form action="?url=area/simpan" method="POST">

            <div class="mb-3">
                <label>Nama Area</label>
                <input
                    type="text"
                    name="nama_area"
                    class="input-gradient"
                    required>
            </div>

            <div class="mb-3">
                <label>Kapasitas</label>
                <input
                    type="number"
                    name="kapasitas"
                    class="input-gradient"
                    required>
            </div>

            <button class="btn btn-gradient">
                <i class="bi bi-check-circle"></i> Simpan
            </button>
            <a href="?url=area/index" class="btn btn-gradient">
                <i class="bi bi-arrow-left-circle"></i> Kembali
            </a>

        </form>

    </div>

</div>