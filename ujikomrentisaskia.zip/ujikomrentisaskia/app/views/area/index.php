<div class="main-content">

    <div class="content-box">

        <h3>Data Area Parkir</h3>

        <a href="?url=area/tambah" class="btn btn-gradient mb-3">
            <i class="bi bi-plus-circle"></i> Tambah Area
        </a>

        <!-- PESAN SUCCESS -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success']; ?>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <!-- PESAN ERROR -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?= $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <table class="table-gradient">

            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Area</th>
                    <th>Kapasitas</th>
                    <th>Terisi</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>

                <?php
                $no = 1;
                if (!empty($area)):
                    foreach ($area as $a):
                ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $a['nama_area']; ?></td>
                            <td><?= $a['kapasitas']; ?></td>
                            <td><?= $a['terisi']; ?></td>
                            <td>
                                <a href="?url=area/edit/<?= $a['id']; ?>" class="btn btn-gradient">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </a>

                                <a href="?url=area/hapus/<?= $a['id']; ?>"
                                    class="btn btn-gradient"
                                    onclick="return confirm('Yakin hapus?')">
                                    <i class="bi bi-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                <?php
                    endforeach;
                endif;
                ?>

            </tbody>

        </table>

    </div>

</div>