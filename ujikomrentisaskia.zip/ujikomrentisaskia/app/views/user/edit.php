<div class="main-content">

    <div class="content-box">

        <h2>Edit User</h2>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="bi bi-exclamation-triangle"></i> <?= $_SESSION['error']; ?>
            </div>
        <?php unset($_SESSION['error']);
        endif; ?>

        <form action="?url=user/update" method="POST">

            <input type="hidden" name="id" value="<?= $user['id']; ?>">

            <div class="mb-3">
                <label>Nama Lengkap</label>
                <input
                    type="text"
                    name="nama_lengkap"
                    value="<?= htmlspecialchars($user['nama_lengkap']); ?>"
                    required>
            </div>

            <div class="mb-3">
                <label>Username</label>
                <input
                    type="text"
                    name="username"
                    value="<?= htmlspecialchars($user['username']); ?>"
                    required>
            </div>

            <div class="mb-3">
                <label>Password (kosongkan jika tidak diubah)</label>
                <input
                    type="text"
                    name="password">
            </div>

            <div class="mb-3">
                <label>Role</label>
                <select name="role" required>
                    <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="petugas" <?= $user['role'] == 'petugas' ? 'selected' : ''; ?>>Petugas</option>
                    <option value="owner" <?= $user['role'] == 'owner' ? 'selected' : ''; ?>>Owner</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Status Aktif</label>
                <select name="status_aktif" required>
                    <option value="1" <?= $user['status_aktif'] ? 'selected' : ''; ?>>Aktif</option>
                    <option value="0" <?= !$user['status_aktif'] ? 'selected' : ''; ?>>Nonaktif</option>
                </select>
            </div>

            <button type="submit" class="btn btn-gradient">
                <i class="bi bi-pencil-square"></i> Update
            </button>

            <a href="?url=user/index" class="btn btn-gradient">
                <i class="bi bi-x-circle"></i> Batal
            </a>

        </form>

    </div>

</div>