<div class="main-content">

    <div class="content-box">

        <h2>Tambah User</h2>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="bi bi-exclamation-triangle"></i> <?= $_SESSION['error']; ?>
            </div>
        <?php unset($_SESSION['error']); endif; ?>

        <form action="?url=user/simpan" method="POST">

            <div class="mb-3">
                <label>Nama Lengkap</label>
                <input type="text" name="nama_lengkap" required>
            </div>

            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" required>
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="text" name="password" required>
            </div>

            <div class="mb-3">
                <label>Role</label>
                <select name="role" required>
                    <option value="">-- Pilih Role --</option>
                    <option value="admin">Admin</option>
                    <option value="petugas">Petugas</option>
                    <option value="owner">Owner</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Status Aktif</label>
                <select name="status_aktif" required>
                    <option value="1">Aktif</option>
                    <option value="0">Nonaktif</option>
                </select>
            </div>

            <button type="submit" class="btn btn-gradient">
                <i class="bi bi-save"></i> Simpan
            </button>
            <a href="?url=user/index" class="btn btn-gradient">
                <i class="bi bi-x-circle"></i> Batal
            </a>

        </form>

    </div>

</div>