<div class="main-content">

    <div class="content-box">

        <h2>Data User</h2>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle"></i> <?= $_SESSION['success']; ?>
            </div>
        <?php unset($_SESSION['success']);
        endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="bi bi-exclamation-triangle"></i> <?= $_SESSION['error']; ?>
            </div>
        <?php unset($_SESSION['error']);
        endif; ?>

        <a href="?url=user/tambah" class="btn btn-gradient mb-2">
            <i class="bi bi-person-plus"></i> Tambah User
        </a>

        <?php if (!empty($user)): ?>

            <table class="table-gradient">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Status Aktif</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $no = 1;
                    foreach ($user as $u): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= htmlspecialchars($u['nama_lengkap']); ?></td>
                            <td><?= htmlspecialchars($u['username']); ?></td>
                            <td><?= htmlspecialchars($u['role']); ?></td>
                            <td>
                                <?= $u['status_aktif'] == 1
                                    ? '<span class="badge-active">Aktif</span>'
                                    : '<span class="badge-nonaktif">Nonaktif</span>'; ?>
                            </td>
                            <td>
                                <a href="?url=user/edit/<?= $u['id']; ?>" class="btn btn-gradient">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </a>
                                <a href="?url=user/hapus/<?= $u['id']; ?>" class="btn btn-gradient"
                                    onclick="return confirm('Hapus user ini?')">
                                    <i class="bi bi-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>

            </table>

        <?php else: ?>
            <p>Data user kosong.</p>
        <?php endif; ?>

    </div>

</div>