<div class="main-content">

    <div class="content-box">

        <h2>Log Aktivitas</h2>

        <?php if (!empty($log)) :
            $no = ($currentPage - 1) * 50 + 1;
        ?>

            <form method="GET" style="margin-bottom:15px;">
                <input type="hidden" name="url" value="log/index">
                <input type="text" name="cari" placeholder="Cari nama user atau aktivitas"
                    value="<?= htmlspecialchars($data['keyword'] ?? '') ?>">
                <button type="submit" class="btn btn-gradient">Cari</button>
                <a href="?url=log/index" class="btn btn-gradient">Reset</a>
            </form>

            <table class="table-gradient">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>User</th>
                        <th>Aktivitas</th>
                        <th>Waktu</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($log as $l) : ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= htmlspecialchars($l['nama_lengkap']); ?></td>
                            <td><?= htmlspecialchars($l['aktivitas']); ?></td>
                            <td><?= date('Y-m-d H:i:s', strtotime($l['waktu'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>

            </table>

            <div class="pagination">

                <?php
                // ambil keyword dari GET untuk dibawa ke link
                $cariParam = !empty($data['keyword']) ? '&cari=' . urlencode($data['keyword']) : '';
                ?>

                <?php if ($currentPage > 1) : ?>
                    <a href="?url=log/index&page=<?= $currentPage - 1 ?><?= $cariParam ?>">Prev</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPage; $i++) : ?>
                    <a href="?url=log/index&page=<?= $i ?><?= $cariParam ?>"
                        class="<?= ($i == $currentPage) ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <?php if ($currentPage < $totalPage) : ?>
                    <a href="?url=log/index&page=<?= $currentPage + 1 ?><?= $cariParam ?>">Next</a>
                <?php endif; ?>

            </div>

        <?php else : ?>
            <p>Belum ada aktivitas.</p>
        <?php endif; ?>

    </div>

</div>