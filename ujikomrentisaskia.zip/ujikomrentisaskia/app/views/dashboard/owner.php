<div class="main-content">

    <div class="content-box">

        <h2>
            Selamat datang, <strong><?= $_SESSION['user']['nama_lengkap']; ?></strong> (Owner)
        </h2>

        <hr style="border-color:#6B46C1; margin-bottom:15px;">

        <p>
            Dashboard Owner digunakan untuk melihat laporan dan pendapatan parkir.
        </p>

        <div style="margin-top:20px;">
            <a href="?url=laporan/index" class="btn btn-gradient">
                <i class="bi bi-file-earmark-text"></i> Lihat Laporan Parkir
            </a>
        </div>

    </div>

</div>