<div class="main-content">

    <div class="content-box">

        <h2>Selamat datang, <strong><?= $_SESSION['user']['nama_lengkap']; ?></strong> (Petugas)</h2>
        <hr style="border-color:#6B46C1; margin-bottom:15px;">

        <!-- Dashboard Cards -->
        <div class="dashboard-cards">

            <div class="card">
                <h3>Transaksi Masuk Hari Ini</h3>
                <p><?= $transaksiMasukHariIni ?? 0; ?></p>
            </div>

            <div class="card">
                <h3>Transaksi Keluar Hari Ini</h3>
                <p><?= $transaksiKeluarHariIni ?? 0; ?></p>
            </div>

            <div class="card">
                <h3>Total Transaksi Hari Ini</h3>
                <p><?= $totalTransaksiHariIni ?? 0; ?></p>
            </div>

        </div>

    </div>

</div>