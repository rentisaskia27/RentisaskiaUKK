<?php require_once '../app/views/layouts/header.php'; ?>
<?php require_once '../app/views/layouts/sidebar_admin.php'; ?>

<div class="main-content">

    <div class="content-box">
        <h2>Dashboard Admin</h2>
        <p>Selamat datang, <strong><?= $_SESSION['user']['nama_lengkap']; ?></strong></p>
        <hr style="border-color:#6B46C1;">

        <!-- Dashboard Cards -->
        <div class="dashboard-cards">

            <div class="card">
                <h3>Total Kendaraan</h3>
                <p><?= $totalKendaraan ?? 0; ?></p>
            </div>

            <div class="card">
                <h3>Total Tarif</h3>
                <p><?= $totalTarif ?? 0; ?></p>
            </div>

            <div class="card">
                <h3>Total User</h3>
                <p><?= $totalUser ?? 0; ?></p>
            </div>

            <div class="card">
                <h3>Total Area Parkir</h3>
                <p><?= $totalArea ?? 0; ?></p>
            </div>

        </div>

    </div>

</div>

<?php require_once '../app/views/layouts/footer.php'; ?>