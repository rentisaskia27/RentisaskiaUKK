<div class="main-content">

    <div class="content-box">

        <h2>Laporan Transaksi Parkir</h2>

        <form method="GET">

            <input type="hidden" name="url" value="laporan/index">

            <div class="mb-3">
                <label>Cari Plat</label>
                <input
                    type="text"
                    name="cari"
                    value="<?= htmlspecialchars($_GET['cari'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label>Tanggal Awal</label>
                <input
                    type="date"
                    name="tanggal_awal"
                    value="<?= $_GET['tanggal_awal'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label>Tanggal Akhir</label>
                <input
                    type="date"
                    name="tanggal_akhir"
                    value="<?= $_GET['tanggal_akhir'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label>Status</label>
                <select name="status">
                    <option value="">Semua</option>
                    <option value="IN" <?= (isset($_GET['status']) && $_GET['status'] == 'IN') ? 'selected' : '' ?>>Sedang Parkir</option>
                    <option value="OUT" <?= (isset($_GET['status']) && $_GET['status'] == 'OUT') ? 'selected' : '' ?>>Menunggu Pembayaran</option>
                    <option value="DONE" <?= (isset($_GET['status']) && $_GET['status'] == 'DONE') ? 'selected' : '' ?>>Selesai</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Area Parkir</label>
                <select name="area">
                    <option value="">Semua Area</option>
                    <?php foreach ($data['areas'] as $area): ?>
                        <option value="<?= htmlspecialchars($area) ?>" <?= (isset($_GET['area']) && $_GET['area'] == $area) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($area) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="btn btn-gradient mb-2">
                Filter
            </button>

            <a href="index.php?url=laporan/index" class="btn btn-gradient mb-2">
                Reset
            </a>

        </form>

        <div style="margin-top:20px; color:#E0E0E0;">
            <strong>
                Total Pendapatan:
                Rp <?= number_format($data['total'] ?? 0, 0, ',', '.') ?>
            </strong>
        </div>

        <table class="table-gradient" style="margin-top:20px;">

            <thead>
                <tr>
                    <th>No</th>
                    <th>Plat</th>
                    <th>Jenis</th>
                    <th>Area</th>
                    <th>Checkin</th>
                    <th>Checkout</th>
                    <th>Durasi</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>

                <?php $no = $data['startNumber']; ?>

                    <?php foreach ($data['transaksi'] as $t): ?>

                    <tr>

                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($t['plat_nomor']); ?></td>
                    <td><?= ucfirst($t['jenis_kendaraan']); ?></td>
                    <td><?= htmlspecialchars($t['nama_area']) ?></td>
                    <td><?= date('d M Y H:i:s', strtotime($t['checkin_time'])); ?></td>
                    <td><?= !empty($t['checkout_time']) ? date('d M Y H:i:s', strtotime($t['checkout_time'])) : '-' ?></td>
                    <td>
                        <?php
                        if (isset($t['duration'])) {
                            $jam = floor($t['duration'] / 60);
                            $menit = $t['duration'] % 60;
                            echo ($jam > 0 ? $jam . " Jam " : "") . $menit . " Menit";
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                    <td><?= isset($t['fee']) ? 'Rp ' . number_format($t['fee'], 0, ',', '.') : '-' ?></td>
                    <td>
                        <?php if ($t['status'] == 'IN'): ?>
                            <span class="badge-success">Sedang Parkir</span>
                        <?php elseif ($t['status'] == 'OUT'): ?>
                            <span class="badge-warning">Menunggu Pembayaran</span>
                        <?php else: ?>
                            <span class="badge-primary">Selesai</span>
                        <?php endif; ?>
                    </td>

                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

        <div class="pagination">

            <?php if ($data['currentPage'] > 1): ?>
                <a href="?url=laporan/index&page=<?= $data['currentPage'] - 1 ?>">Prev</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $data['totalPage']; $i++): ?>
                <a href="?url=laporan/index&page=<?= $i ?>"
                    class="<?= $i == $data['currentPage'] ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if ($data['currentPage'] < $data['totalPage']): ?>
                <a href="?url=laporan/index&page=<?= $data['currentPage'] + 1 ?>">Next</a>
            <?php endif; ?>

        </div>

    </div>

</div>