<?php
$currentUrl = $_GET['url'] ?? '';
?>
<aside class="sidebar">
    <ul>
        <li>
            <a href="?url=dashboard/petugas" class="<?= ($currentUrl == 'dashboard/petugas') ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="menu-item">
            <a href="#" class="menu-toggle">
                <i class="bi bi-cash-stack"></i> Transaksi
            </a>

            <ul class="submenu">
                <li>
                    <a href="?url=transaksi/masuk" class="<?= ($currentUrl == 'transaksi/masuk') ? 'active' : '' ?>">
                        <i class="bi bi-box-arrow-in-down"></i> Transaksi Masuk
                    </a>
                </li>
                <li>
                    <a href="?url=transaksi/checkoutList" class="<?= ($currentUrl == 'transaksi/checkoutList') ? 'active' : '' ?>">
                        <i class="bi bi-box-arrow-up"></i> Transaksi Keluar / Konfirmasi
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="?url=transaksi/riwayat" class="<?= ($currentUrl == 'transaksi/riwayat') ? 'active' : '' ?>">
                <i class="bi bi-clock-history"></i> Riwayat Transaksi
            </a>
        </li>

        <li>
            <a href="?url=auth/logout"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </li>
    </ul>
</aside>