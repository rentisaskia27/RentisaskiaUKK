<?php
$currentUrl = $_GET['url'] ?? '';
$isAuthPage = strpos($currentUrl, 'auth') !== false;
?>

<?php if (!$isAuthPage): ?>
    </div> <!-- end container -->
<?php endif; ?>

<footer class="footer" style="
    background-color: #232336;
    color: #A0AEC0;
    text-align: center;
    padding: 15px 20px;
    border-top: 2px solid #A0AEC0;
">
    <p style="margin:0;">
        &copy; <?= date('Y') ?> Aplikasi Parkir
    </p>
</footer>

<script src="/ujikomrentisaskia/public/assets/js/script.js"></script>
</body>

</html>