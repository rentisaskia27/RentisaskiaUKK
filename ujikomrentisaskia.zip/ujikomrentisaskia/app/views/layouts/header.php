<?php
$user = $_SESSION['user'] ?? null;
$role = $user['role'] ?? null;

$currentUrl = $_GET['url'] ?? '';
$isAuthPage = strpos($currentUrl, 'auth') !== false;
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <title>
        APLIKASI PARKIR <?= $role ? '- ' . ucfirst($role) : '- Login' ?>
    </title>

    <link rel="stylesheet" href="/ujikomrentisaskia/public/assets/css/style.css">

    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>

<body>

    <header class="topbar">
        <h1 style="
        margin:0;
        font-size:1.6rem;
        font-weight:bold;
        text-align:center;
        letter-spacing:1px;
    ">
            APLIKASI PARKIR
            <?= $role ? '- ' . strtoupper($role) : '- LOGIN' ?>
        </h1>
    </header>

    <?php if (!$isAuthPage): ?>
        <div class="container">

            <?php if ($role): ?>

                <?php
                if ($role == 'admin') {
                    require_once '../app/views/layouts/sidebar_admin.php';
                } elseif ($role == 'petugas') {
                    require_once '../app/views/layouts/sidebar_petugas.php';
                } elseif ($role == 'owner') {
                    require_once '../app/views/layouts/sidebar_owner.php';
                }
                ?>

            <?php endif; ?>

        <?php endif; ?>