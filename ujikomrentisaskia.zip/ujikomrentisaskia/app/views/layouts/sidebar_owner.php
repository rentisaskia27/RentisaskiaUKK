<?php
$currentUrl = $_GET['url'] ?? '';
?>
<aside class="sidebar">
    <ul>
        <li>
            <a href="?url=dashboard/owner" class="<?= ($currentUrl == 'dashboard/owner') ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li>
            <a href="?url=laporan/index" class="<?= ($currentUrl == 'laporan/index') ? 'active' : '' ?>">
                <i class="bi bi-file-earmark-text"></i> Laporan Transaksi
            </a>
        </li>

        <li>
            <a href="?url=auth/logout">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </li>
    </ul>
</aside>