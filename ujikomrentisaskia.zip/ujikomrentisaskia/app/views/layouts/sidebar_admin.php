<?php
$currentUrl = $_GET['url'] ?? '';
?>

<aside class="sidebar">
    <ul>
        <li>
            <a href="?url=dashboard/admin" class="<?= ($currentUrl == 'dashboard/admin') ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="menu-item">
            <a href="#" class="menu-toggle">
                <i class="bi bi-car-front"></i> Kelola Kendaraan
            </a>

            <ul class="submenu">
                <li>
                    <a href="?url=kendaraan/index" class="<?= ($currentUrl == 'kendaraan/index') ? 'active' : '' ?>">
                        <i class="bi bi-list"></i> List Kendaraan
                    </a>
                </li>
                <li>
                    <a href="?url=kendaraan/tambah" class="<?= ($currentUrl == 'kendaraan/tambah') ? 'active' : '' ?>">
                        <i class="bi bi-plus-circle"></i> Tambah Kendaraan
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item">
            <a href="#" class="menu-toggle">
                <i class="bi bi-cash-stack"></i> Kelola Tarif
            </a>

            <ul class="submenu">
                <li>
                    <a href="?url=tarif/index" class="<?= ($currentUrl == 'tarif/index') ? 'active' : '' ?>">
                        <i class="bi bi-list"></i> List Tarif
                    </a>
                </li>
                <li>
                    <a href="?url=tarif/tambah" class="<?= ($currentUrl == 'tarif/tambah') ? 'active' : '' ?>">
                        <i class="bi bi-plus-circle"></i> Tambah Tarif
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item">
            <a href="#" class="menu-toggle">
                <i class="bi bi-people"></i> Kelola User
            </a>

            <ul class="submenu">
                <li>
                    <a href="?url=user/index" class="<?= ($currentUrl == 'user/index') ? 'active' : '' ?>">
                        <i class="bi bi-list"></i> List User
                    </a>
                </li>
                <li>
                    <a href="?url=user/tambah" class="<?= ($currentUrl == 'user/tambah') ? 'active' : '' ?>">
                        <i class="bi bi-plus-circle"></i> Tambah User
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item">
            <a href="#" class="menu-toggle">
                <i class="bi bi-map"></i> Data Area Parkir
            </a>

            <ul class="submenu">
                <li>
                    <a href="?url=area/index" class="<?= ($currentUrl == 'area/index') ? 'active' : '' ?>">
                        <i class="bi bi-list"></i> List Area
                    </a>
                </li>
                <li>
                    <a href="?url=area/tambah" class="<?= ($currentUrl == 'area/tambah') ? 'active' : '' ?>">
                        <i class="bi bi-plus-circle"></i> Tambah Area
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="?url=log/index" class="<?= ($currentUrl == 'log/index') ? 'active' : '' ?>">
                <i class="bi bi-journal-text"></i> Log Aktivitas
            </a>
        </li>

        <li>
            <a href="?url=auth/logout"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </li>
    </ul>
</aside>