<?php

class Area extends Model
{
    private $table = 'area_parkir';

    // ambil semua data area
    public function getAll()
    {
        $query = "SELECT * FROM area_parkir ORDER BY id ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // hitung total area
    public function countAll()
    {
        $stmt = $this->db->query("SELECT COUNT(*) AS total FROM area_parkir");
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // ambil berdasarkan id
    public function getById($id)
    {
        $query = "SELECT * FROM area_parkir WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // ambil area pertama yang masih tersedia lewat RFID
    public function getAvailable()
    {
        $stmt = $this->db->prepare("
        SELECT * FROM area_parkir 
        WHERE terisi < kapasitas 
        ORDER BY id ASC 
        LIMIT 1
    ");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tambah kendaraan → terisi +1
    public function incrementTerisi($id)
    {
        // CEK KAPASITAS
        $area = $this->getById($id);

        if ($area['terisi'] >= $area['kapasitas']) {

            return "penuh";
        }

        $query = "UPDATE area_parkir 
                  SET terisi = terisi + 1 
                  WHERE id = :id";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    // Kendaraan keluar → terisi -1
    public function decrementTerisi($id)
    {
        $query = "UPDATE area_parkir 
                  SET terisi = GREATEST(terisi - 1, 0) 
                  WHERE id = :id";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    // simpan area (insert)
    public function insert($data)
    {
        try {

            $query = "INSERT INTO area_parkir (nama_area, kapasitas, terisi)
                      VALUES (:nama_area, :kapasitas, :terisi)";

            $stmt = $this->db->prepare($query);

            $terisi = isset($data['terisi']) ? $data['terisi'] : 0;

            $stmt->bindParam(':nama_area', $data['nama_area']);
            $stmt->bindParam(':kapasitas', $data['kapasitas']);
            $stmt->bindParam(':terisi', $terisi);

            return $stmt->execute();
        } catch (PDOException $e) {

            // duplicate nama_area
            if ($e->getCode() == '23505') {

                return false;
            }

            throw $e;
        }
    }

    // update area
    public function update($data)
    {
        try {

            // ambil data lama
            $lama = $this->getById($data['id']);

            // validasi kapasitas tidak boleh kurang dari terisi
            if ($data['kapasitas'] < $lama['terisi']) {

                return "kapasitas_kurang";
            }

            $query = "UPDATE area_parkir SET
                      nama_area = :nama_area,
                      kapasitas = :kapasitas,
                      terisi = :terisi
                      WHERE id = :id";

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':id', $data['id']);
            $stmt->bindParam(':nama_area', $data['nama_area']);
            $stmt->bindParam(':kapasitas', $data['kapasitas']);
            $stmt->bindParam(':terisi', $data['terisi']);

            return $stmt->execute();
        } catch (PDOException $e) {

            if ($e->getCode() == '23505') {

                return false;
            }

            throw $e;
        }
    }

    // hapus area (delete)
    public function delete($id)
    {
        // CEK apakah masih digunakan
        $query = "SELECT COUNT(*) FROM transaksi
                  WHERE area_id = :id
                  AND checkout_time IS NULL";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {

            return "masih_digunakan";
        }

        $query = "DELETE FROM area_parkir WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
