<?php

class Tarif extends Model
{
    private $table = 'tarif';

    // ambil semua data tarif
    public function getAll()
    {
        $query = "SELECT * FROM tarif ORDER BY id ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // hitung total tarif
    public function countAll()
    {
        $stmt = $this->db->query("SELECT COUNT(*) AS total FROM tarif");
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // ambil berdasarkan id
    public function getById($id)
    {
        $query = "SELECT * FROM tarif WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // ambil tarif berdasarkan jenis kendaraan (untuk TransaksiController)
    public function getByJenisKendaraan($jenis)
    {
        $query = "SELECT * FROM tarif WHERE jenis_kendaraan = :jenis";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':jenis', $jenis);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // simpan tarif // insert
    public function insert($data)
    {
        // Cek jenis_kendaraan sudah ada
        $queryCheck = "SELECT id FROM tarif WHERE jenis_kendaraan = :jenis_kendaraan";
        $stmtCheck = $this->db->prepare($queryCheck);
        $stmtCheck->bindParam(':jenis_kendaraan', $data['jenis_kendaraan']);
        $stmtCheck->execute();
        if ($stmtCheck->rowCount() > 0) {
            return false; // Bisa dikembalikan false atau lempar error custom
        }

        try {

            $query = "INSERT INTO tarif (jenis_kendaraan, tarif_per_jam)
                  VALUES (:jenis_kendaraan, :tarif_per_jam)";

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':jenis_kendaraan', $data['jenis_kendaraan']);
            $stmt->bindParam(':tarif_per_jam', $data['tarif_per_jam']);

            return $stmt->execute();
        } catch (PDOException $e) {

            return false;
        }
    }

    // update tarif
    public function update($data)
    {
        try {

            $query = "UPDATE tarif
                  SET jenis_kendaraan = :jenis_kendaraan,
                      tarif_per_jam = :tarif_per_jam
                  WHERE id = :id";

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':id', $data['id']);
            $stmt->bindParam(':jenis_kendaraan', $data['jenis_kendaraan']);
            $stmt->bindParam(':tarif_per_jam', $data['tarif_per_jam']);

            return $stmt->execute();
        } catch (PDOException $e) {

            return false;
        }
    }

    // cek ada kendaraan yang masih menggunakan tarif ini
    public function kendaraanTerpakai($id)
    {
        $stmt = $this->db->prepare("
            SELECT * FROM kendaraan WHERE tarif_id = :id
        ");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // delete
    public function delete($id)
    {
        // cek kendaraan terpakai
        $kendaraanTerpakai = $this->kendaraanTerpakai($id);
        if (!empty($kendaraanTerpakai)) {
            return false; // tidak bisa hapus
        }

        $stmt = $this->db->prepare("DELETE FROM tarif WHERE id = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // ambil tarif aktif berdasarkan jenis kendaraan
    public function getByJenisKendaraanAktif($jenis)
    {
        $stmt = $this->db->prepare("SELECT * FROM tarif WHERE jenis_kendaraan = :jenis");
        $stmt->bindParam(':jenis', $jenis);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
