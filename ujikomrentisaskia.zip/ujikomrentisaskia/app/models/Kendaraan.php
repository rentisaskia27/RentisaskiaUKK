<?php

class Kendaraan extends Model
{
    private $table = 'kendaraan';

    // ambil semua data kendaraan
    public function getAll()
    {
        $query = "SELECT k.*, t.jenis_kendaraan AS jenis_tarif, t.tarif_per_jam
              FROM kendaraan k
              LEFT JOIN tarif t ON k.tarif_id = t.id
              WHERE k.status_aktif = true
              ORDER BY k.id DESC";

        $stmt = $this->db->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // hitung total kendaraan aktif (status_aktif = true)
    public function countAll()
    {
        $stmt = $this->db->query("SELECT COUNT(*) AS total FROM kendaraan WHERE status_aktif = true");
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // ambil kendaraan berdasarkan ID
    public function getById($id)
    {
        $query = "SELECT * FROM kendaraan WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // simpan data kendaraan
    public function insert($data)
    {
        try {
            $query = "INSERT INTO kendaraan (card_id, plat_nomor, jenis_kendaraan, tarif_id)
                      VALUES (:card_id, :plat_nomor, :jenis_kendaraan, :tarif_id)";

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':card_id', $data['card_id']);
            $stmt->bindParam(':plat_nomor', $data['plat_nomor']);
            $stmt->bindParam(':jenis_kendaraan', $data['jenis_kendaraan']);
            $stmt->bindParam(':tarif_id', $data['tarif_id']);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    // update data kendaraan
    public function update($data)
    {
        try {
            $query = "UPDATE kendaraan SET
                      card_id = :card_id,
                      plat_nomor = :plat_nomor,
                      tarif_id = :tarif_id
                      WHERE id = :id";

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':id', $data['id']);
            $stmt->bindParam(':card_id', $data['card_id']);
            $stmt->bindParam(':plat_nomor', $data['plat_nomor']);
            $stmt->bindParam(':tarif_id', $data['tarif_id']);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    // hapus kendaraan (langsung delete)
    public function delete($id)
    {
        $stmt = $this->db->prepare("
        UPDATE kendaraan
        SET status_aktif = false
        WHERE id = :id
    ");

        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // cari berdasarkan card_id RFID
    public function getByCardId($card_id)
    {
        $query = "SELECT * FROM kendaraan 
              WHERE card_id = :card_id
              AND status_aktif = true";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':card_id', $card_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // cari kendaraan berdasarkan plat nomor
    public function getByPlat($plat_nomor)
    {
        $query = "SELECT * FROM kendaraan 
              WHERE plat_nomor = :plat_nomor
              AND status_aktif = true";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':plat_nomor', $plat_nomor);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
