<?php
require_once __DIR__ . '/../core/Model.php';

class User extends Model
{

    private $table = 'users';

    // Ambil semua user
    public function getAll()
    {
        $query = "SELECT * FROM {$this->table} ORDER BY id ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // hitung total user
    public function countAll()
    {
        $stmt = $this->db->query("SELECT COUNT(*) AS total FROM users");
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // Ambil user berdasarkan id
    public function getById($id)
    {
        $query = "SELECT * FROM {$this->table} WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Ambil user berdasarkan username aktif (login)
    public function getUserByUsername($username)
    {
        $sql = "SELECT * FROM {$this->table} WHERE username = :username AND status_aktif = true";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // INSERT USER
    public function insert($data)
    {
        try {

            $query = "INSERT INTO {$this->table}
                     (nama_lengkap, username, password, role, status_aktif)
                      VALUES
                     (:nama_lengkap, :username, :password, :role, :status_aktif)";

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':nama_lengkap', $data['nama_lengkap']);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':password', $data['password']);
            $stmt->bindParam(':role', $data['role']);

            $status = isset($data['status_aktif']) ? $data['status_aktif'] : 1;

            $stmt->bindParam(':status_aktif', $status);

            return $stmt->execute();
        } catch (PDOException $e) {

            if ($e->getCode() == '23505') {

                return false;
            }

            throw $e;
        }
    }

    // UPDATE USER
    public function update($data)
    {
        try {

            if (!empty($data['password'])) {

                $query = "UPDATE {$this->table} SET 
                          nama_lengkap = :nama_lengkap,
                          username = :username,
                          password = :password,
                          role = :role,
                          status_aktif = :status_aktif
                          WHERE id = :id";
            } else {

                $query = "UPDATE {$this->table} SET 
                          nama_lengkap = :nama_lengkap,
                          username = :username,
                          role = :role,
                          status_aktif = :status_aktif
                          WHERE id = :id";
            }

            $stmt = $this->db->prepare($query);

            $stmt->bindParam(':id', $data['id']);
            $stmt->bindParam(':nama_lengkap', $data['nama_lengkap']);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':role', $data['role']);
            $stmt->bindParam(':status_aktif', $data['status_aktif']);

            if (!empty($data['password'])) {

                $stmt->bindParam(':password', $data['password']);
            }

            return $stmt->execute();
        } catch (PDOException $e) {

            if ($e->getCode() == '23505') {

                return false;
            }

            throw $e;
        }
    }

    // DELETE USER
    public function delete($id)
    {
        $query = "DELETE FROM {$this->table} WHERE id = :id";

        $stmt = $this->db->prepare($query);

        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }
}
