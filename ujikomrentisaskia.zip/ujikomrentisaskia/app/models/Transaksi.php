<?php
require_once __DIR__ . '/../core/Model.php';

class Transaksi extends Model
{

    private $table = 'transaksi';

    // Ambil semua transaksi (dengan join kendaraan, user, area)
    public function getAll()
    {
        $query = "SELECT t.*, k.plat_nomor, k.jenis_kendaraan, u.nama_lengkap AS petugas, a.nama_area
              FROM {$this->table} t
              LEFT JOIN kendaraan k ON t.kendaraan_id = k.id
              LEFT JOIN users u ON t.petugas_id = u.id
              LEFT JOIN area_parkir a ON t.area_id = a.id
              WHERE t.status IN ('IN','OUT','DONE')
              ORDER BY t.id DESC";

        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Ambil transaksi dengan filter dan pagination untuk Owner
    public function getFiltered($cari, $tanggal_awal, $tanggal_akhir, $status, $area, $limit, $offset)
    {
        $query = "SELECT t.*, 
                     k.plat_nomor, 
                     k.jenis_kendaraan, 
                     a.nama_area
              FROM transaksi t
              LEFT JOIN kendaraan k ON t.kendaraan_id = k.id
              LEFT JOIN area_parkir a ON t.area_id = a.id
              WHERE 1=1";

        if (!empty($cari)) {
            $query .= " AND k.plat_nomor ILIKE :cari";
        }

        if (!empty($status)) {
            $query .= " AND t.status = :status";
        }

        if (!empty($area)) {
            $query .= " AND a.nama_area = :area";
        }

        if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
            $query .= " AND DATE(t.checkin_time) BETWEEN :awal AND :akhir";
        }

        $query .= " ORDER BY t.id DESC LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);

        if (!empty($cari)) {
            $stmt->bindValue(':cari', "%$cari%");
        }

        if (!empty($status)) {
            $stmt->bindValue(':status', $status);
        }

        if (!empty($area)) {
            $stmt->bindValue(':area', $area);
        }

        if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
            $stmt->bindValue(':awal', $tanggal_awal);
            $stmt->bindValue(':akhir', $tanggal_akhir);
        }

        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Hitung total transaksi dengan filter untuk pagination untk Owner
    public function countFiltered($cari, $tanggal_awal, $tanggal_akhir, $status, $area)
    {
        $query = "SELECT COUNT(*) as total
              FROM transaksi t
              LEFT JOIN kendaraan k ON t.kendaraan_id = k.id
              LEFT JOIN area_parkir a ON t.area_id = a.id
              WHERE 1=1";

        if (!empty($cari)) {
            $query .= " AND k.plat_nomor ILIKE :cari";
        }

        if (!empty($status)) {
            $query .= " AND t.status = :status";
        }

        if (!empty($area)) {
            $query .= " AND a.nama_area = :area";
        }

        if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
            $query .= " AND DATE(t.checkin_time) BETWEEN :awal AND :akhir";
        }

        $stmt = $this->db->prepare($query);

        if (!empty($cari)) {
            $stmt->bindValue(':cari', "%$cari%");
        }

        if (!empty($status)) {
            $stmt->bindValue(':status', $status);
        }

        if (!empty($area)) {
            $stmt->bindValue(':area', $area);
        }

        if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
            $stmt->bindValue(':awal', $tanggal_awal);
            $stmt->bindValue(':akhir', $tanggal_akhir);
        }

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // Ambil 50 Data
    public function getRiwayat($limit, $offset)
    {
        $query = "SELECT t.*, 
                     k.plat_nomor, 
                     k.jenis_kendaraan, 
                     u.nama_lengkap AS petugas, 
                     a.nama_area
              FROM transaksi t
              LEFT JOIN kendaraan k ON t.kendaraan_id = k.id
              LEFT JOIN users u ON t.petugas_id = u.id
              LEFT JOIN area_parkir a ON t.area_id = a.id
              WHERE t.status IN ('IN','OUT','DONE')
              ORDER BY t.id DESC
              LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Hitung total transaksi untuk pagination maks 500
    public function countRiwayat()
    {
        $query = "SELECT COUNT(*) as total 
              FROM transaksi 
              WHERE status IN ('IN','OUT','DONE')";

        $stmt = $this->db->prepare($query);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return min($result['total'], 500);
    }

    // Ambil transaksi berdasarkan id
    public function getById($id)
    {
        $query = "SELECT * FROM {$this->table} WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tambah transaksi baru (check-in)
    public function insert($data)
    {
        $query = "INSERT INTO {$this->table} 
    (kendaraan_id, petugas_id, area_id, checkin_time, tarif_per_jam, status)
    
    VALUES 
    (:kendaraan_id, :petugas_id, :area_id, :checkin_time, :tarif_per_jam, 'IN')";

        $stmt = $this->db->prepare($query);

        $stmt->bindParam(':kendaraan_id', $data['kendaraan_id']);
        $stmt->bindParam(':petugas_id', $data['petugas_id']);
        $stmt->bindParam(':area_id', $data['area_id']);
        $stmt->bindParam(':checkin_time', $data['checkin_time']);
        $stmt->bindParam(':tarif_per_jam', $data['tarif_per_jam']);

        return $stmt->execute();
    }

    // Update transaksi (checkout)
    public function updateCheckout($id, $checkout_time, $duration, $fee)
    {
        $query = "UPDATE {$this->table} SET 
                  checkout_time = :checkout_time,
                  duration = :duration,
                  fee = :fee,
                  status = 'OUT'
                  WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':checkout_time', $checkout_time);
        $stmt->bindParam(':duration', $duration);
        $stmt->bindParam(':fee', $fee);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // cek kendaraan masih parkir
    public function kendaraanMasihParkir($kendaraan_id)
    {
        $query = "SELECT * FROM {$this->table} 
              WHERE kendaraan_id = :kendaraan_id AND status IN ('IN', 'OUT')
              ORDER BY checkin_time DESC LIMIT 1";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':kendaraan_id', $kendaraan_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Ambil transaksi yang masih IN (kendaraan di parkir)
    public function getActiveByKendaraan($kendaraan_id)
    {
        $query = "SELECT 
                t.*,
                a.nama_area
              FROM transaksi t
              LEFT JOIN area_parkir a ON t.area_id = a.id
              WHERE t.kendaraan_id = :kendaraan_id 
              AND t.status = 'IN'
              ORDER BY t.checkin_time DESC 
              LIMIT 1";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':kendaraan_id', $kendaraan_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    //
    public function getAllActive()
    {
        $stmt = $this->db->prepare("
        SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area, u.nama_lengkap AS petugas
        FROM transaksi t
        JOIN kendaraan k ON t.kendaraan_id = k.id
        JOIN area_parkir a ON t.area_id = a.id
        LEFT JOIN users u ON t.petugas_id = u.id
        WHERE t.status = 'OUT'
        ORDER BY t.checkin_time ASC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateStatus($id, $status)
    {
        $query = "UPDATE {$this->table} 
              SET status = :status 
              WHERE id = :id";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    // Konfirmasi checkout (ubah status ke DONE)
    public function konfirmasiCheckout($id, $petugas_id)
    {
        $query = "UPDATE {$this->table} 
              SET petugas_id = :petugas_id,
                  status = 'DONE'
              WHERE id = :id";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':petugas_id', $petugas_id);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }





    // Hitung transaksi masuk hari ini
    public function countMasukHariIni()
    {
        $query = "SELECT COUNT(*) as total 
              FROM transaksi 
              WHERE DATE(checkin_time) = CURRENT_DATE";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return (int) $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // Hitung transaksi keluar hari ini
    public function countKeluarHariIni()
    {
        $query = "SELECT COUNT(*) as total 
              FROM transaksi 
              WHERE DATE(checkout_time) = CURRENT_DATE";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return (int) $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // Hitung total transaksi hari ini (baik masuk atau keluar)
    public function countTotalHariIni()
    {
        $query = "SELECT COUNT(*) as total 
              FROM transaksi 
              WHERE DATE(checkin_time) = CURRENT_DATE 
                 OR DATE(checkout_time) = CURRENT_DATE";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return (int) $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }
}
