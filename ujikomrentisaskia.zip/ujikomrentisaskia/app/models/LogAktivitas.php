<?php
require_once __DIR__ . '/../core/Model.php';

class LogAktivitas extends Model
{
    private $table = 'log_aktivitas';

    public function insert($data)
    {
        $query = "INSERT INTO log_aktivitas (user_id, aktivitas) VALUES (:user_id, :aktivitas)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $data['user_id']);
        $stmt->bindParam(':aktivitas', $data['aktivitas']);
        return $stmt->execute();
    }

    public function getAll()
    {
        $query = "SELECT l.*, u.nama_lengkap FROM log_aktivitas l 
                  LEFT JOIN users u ON l.user_id = u.id
                  ORDER BY l.waktu DESC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getLimit($limit, $offset)
    {
        $query = "SELECT l.*, u.nama_lengkap
              FROM log_aktivitas l
              LEFT JOIN users u ON l.user_id = u.id
              ORDER BY l.waktu DESC
              LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mencari log berdasarkan keyword (nama pengguna / aktivitas)
    public function search($keyword, $limit, $offset)
    {
        $query = "SELECT l.*, u.nama_lengkap 
              FROM log_aktivitas l
              LEFT JOIN users u ON l.user_id = u.id
              WHERE u.nama_lengkap ILIKE :keyword OR l.aktivitas ILIKE :keyword
              ORDER BY l.waktu DESC
              LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);
        $like = "%$keyword%";
        $stmt->bindParam(':keyword', $like);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
