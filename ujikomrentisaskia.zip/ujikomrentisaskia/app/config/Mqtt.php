<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

class Mqtt
{
    public static function publish($topic, $message)
    {
        $server   = 'broker.hivemq.com';
        $port     = 1883;
        $clientId = 'php_' . rand(1000,9999);

        $connectionSettings = (new ConnectionSettings);

        $mqtt = new MqttClient($server, $port, $clientId);

        $mqtt->connect($connectionSettings, true);
        $mqtt->publish($topic, $message);
        $mqtt->disconnect();
    }
}