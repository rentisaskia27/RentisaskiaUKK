<?php
class Database
{
    private static $conn = null;

    public static function getConnection()
    {
        if (self::$conn === null) {

            $host = "aws-1-ap-southeast-2.pooler.supabase.com"; // Supabase host
            $port = 6543;  // Pooler port
            $dbname = "postgres";
            $user = "postgres.rlqikwdqevdmltpoqniw"; // Supabase user
            $password = "rentiujikom123"; // Supabase password

            try {
                $dsn = "pgsql:host=$host;port=$port;dbname=$dbname";
                self::$conn = new PDO($dsn, $user, $password);
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            } catch (PDOException $e) {
                die("Koneksi database gagal: " . $e->getMessage());
            }
        }

        return self::$conn;
    }
}
