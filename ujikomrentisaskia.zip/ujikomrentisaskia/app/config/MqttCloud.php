<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

class Mqtt
{
    public static function publish($topic, $message)
    {
        $server   = '968900731866423197501c904bdac4bf.s1.eu.hivemq.cloud';
        $port     = 8883;
        $clientId = 'php_' . rand(1000,9999);

        $connectionSettings = (new ConnectionSettings)
            ->setUsername('JensSMK')
            ->setPassword('JensUjikom04')
            ->setUseTls(true);

        $mqtt = new MqttClient($server, $port, $clientId);

        $mqtt->connect($connectionSettings, true);
        $mqtt->publish($topic, $message);
        $mqtt->disconnect();
    }
}