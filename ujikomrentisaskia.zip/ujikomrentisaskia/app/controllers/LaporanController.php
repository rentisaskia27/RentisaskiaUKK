<?php

class LaporanController extends Controller
{
    private $transaksiModel;

    public function __construct()
    {
        $this->transaksiModel = $this->model('Transaksi');
    }

    public function index()
    {
        $tanggal_awal  = $_GET['tanggal_awal'] ?? null;
        $tanggal_akhir = $_GET['tanggal_akhir'] ?? null;
        $cari          = $_GET['cari'] ?? null;
        $status_filter = $_GET['status'] ?? null;
        $area_filter   = $_GET['area'] ?? null;

        $limit = 50;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($page < 1) {
            $page = 1;
        }

        $offset = ($page - 1) * $limit;

        // ambil data
        $data['transaksi'] = $this->transaksiModel->getFiltered(
            $cari,
            $tanggal_awal,
            $tanggal_akhir,
            $status_filter,
            $area_filter,
            $limit,
            $offset
        );

        // total data
        $totalData = $this->transaksiModel->countFiltered(
            $cari,
            $tanggal_awal,
            $tanggal_akhir,
            $status_filter,
            $area_filter
        );

        // total pendapatan
        $data['total'] = 0;
        foreach ($data['transaksi'] as $t) {
            if ($t['status'] == 'DONE') {
                $data['total'] += $t['fee'];
            }
        }

        // ambil area
        $semua = $this->transaksiModel->getAll();
        $data['areas'] = array_unique(array_map(fn($t) => $t['nama_area'], $semua));

        // pagination
        $data['totalPage'] = ceil($totalData / $limit);
        $data['currentPage'] = $page;
        $data['startNumber'] = $offset + 1;

        $this->view('layouts/header');
        $this->view('layouts/sidebar_owner');
        $this->view('laporan/index', $data);
        $this->view('layouts/footer');
    }
}
