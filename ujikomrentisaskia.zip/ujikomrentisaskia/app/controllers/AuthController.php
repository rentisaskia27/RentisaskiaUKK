<?php

class AuthController extends Controller
{
    /** @var User $userModel */
    private $userModel;

    public function __construct()
    {
        // Pakai model bawaan MVC
        $this->userModel = $this->model('User');
    }

    // Halaman login
    public function index()
    {
        if (isset($_SESSION['user'])) {
            $role = $_SESSION['user']['role'];
            header('Location: index.php?url=dashboard/' . $role);
            exit;
        }
        $this->view('layouts/header');
        $this->view('auth/login');
        $this->view('layouts/footer');
    }

    // Proses login
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            $user = $this->userModel->getUserByUsername($username);

            // Cek password plain text
            if ($user && $password === $user['password']) {
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'nama_lengkap' => $user['nama_lengkap'],
                    'role' => $user['role']
                ];

                header('Location: index.php?url=dashboard/' . $user['role']);
                exit;
            } else {
                $data['error'] = "Username atau password salah!";

                $this->view('layouts/header');
                $this->view('auth/login', $data);
                $this->view('layouts/footer');
            }
        }
    }

    // Logout
    public function logout()
    {
        session_destroy();
        header('Location: index.php?url=auth/index');
        exit;
    }
}
