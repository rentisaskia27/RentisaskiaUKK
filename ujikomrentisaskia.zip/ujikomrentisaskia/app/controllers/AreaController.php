<?php
require_once __DIR__ . '/../helpers/LogHelper.php';
class AreaController extends Controller
{
    private $areaModel;

    public function __construct()
    {
        $this->areaModel = $this->model('Area');
    }

    // tampil semua area
    public function index()
    {
        $data['area'] = $this->areaModel->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('area/index', $data);
        $this->view('layouts/footer');
    }

    // halaman tambah
    public function tambah()
    {
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('area/tambah');
        $this->view('layouts/footer');
    }

    // simpan area
    public function simpan()
    {
        $result = $this->areaModel->insert($_POST);
        if ($result === false) {
            $_SESSION['error'] = "Nama area sudah ada!";
            header('Location: ?url=area/tambah');
            exit;
        }

        logAktivitas($_SESSION['user']['id'], "Menambahkan area parkir: " . $_POST['nama_area'] . " (Kapasitas: " . $_POST['kapasitas'] . ")"); // Log aktivitas tambah area
        $_SESSION['success'] = "Area berhasil ditambahkan!";
        header('Location: ?url=area');
        exit;
    }

    // halaman edit
    public function edit($id)
    {
        $data['area'] = $this->areaModel->getById($id);
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('area/edit', $data);
        $this->view('layouts/footer');
    }

    // update area
    public function update()
    {
        $result = $this->areaModel->update($_POST);
        if ($result === false) {

            $_SESSION['error'] = "Nama area sudah digunakan!";

            header('Location: ?url=area/edit/' . $_POST['id']);
            exit;
        }
        if ($result === "kapasitas_kurang") {

            $_SESSION['error'] = "Kapasitas tidak boleh kurang dari jumlah terisi!";
            header('Location: ?url=area/edit/' . $_POST['id']);
            exit;
        }

        logAktivitas($_SESSION['user']['id'], "Mengubah area parkir: " . $_POST['nama_area'] . " (Kapasitas: " . $_POST['kapasitas'] . ")"); // Log aktivitas update area
        $_SESSION['success'] = "Area berhasil diupdate!";
        header('Location: ?url=area');
        exit;
    }

    // hapus area
    public function hapus($id)
    {
        $area = $this->areaModel->getById($id); // ambil data sebelum dihapus
        $result = $this->areaModel->delete($id);
        if ($result === "masih_digunakan") {

            $_SESSION['error'] = "Area tidak bisa dihapus karena masih digunakan!";

            header('Location: ?url=area');
            exit;
        }
        logAktivitas($_SESSION['user']['id'], "Menghapus area parkir: " . $area['nama_area'] . " (Kapasitas: " . $area['kapasitas'] . ")"); // Log aktivitas hapus area
        $_SESSION['success'] = "Area berhasil dihapus!";
        header('Location: ?url=area');
        exit;
    }
}
