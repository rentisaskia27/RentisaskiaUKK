<?php
require_once __DIR__ . '/../helpers/LogHelper.php';

class KendaraanController extends Controller
{
    private $kendaraanModel;

    public function __construct()
    {
        $this->kendaraanModel = $this->model('Kendaraan');
    }

    public function index()
    {
        $data['kendaraan'] = $this->kendaraanModel->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('kendaraan/index', $data);
        $this->view('layouts/footer');
    }

    public function tambah()
    {
        $data['tarif'] = $this->model('Tarif')->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('kendaraan/tambah', $data);
        $this->view('layouts/footer');
    }

    public function simpan()
    {
        // validasi tarif ada
        $tarif = $this->model('Tarif')->getById($_POST['tarif_id']);
        if (!$tarif) {
            $_SESSION['error'] = "Tarif tidak ditemukan!";
            header('Location: ?url=kendaraan/tambah');
            exit;
        }

        // insert kendaraan
        if ($this->kendaraanModel->insert($_POST)) {
            $_SESSION['success'] = "Data kendaraan berhasil ditambahkan!";
            logAktivitas($_SESSION['user']['id'], "Menambahkan kendaraan: " . $_POST['plat_nomor']);
            header('Location: ?url=kendaraan');
            exit;
        } else {
            $_SESSION['error'] = "Card ID atau Plat Nomor sudah digunakan!";
            header('Location: ?url=kendaraan/tambah');
            exit;
        }
    }

    public function edit($id)
    {
        $data['kendaraan'] = $this->kendaraanModel->getById($id);
        $data['tarif'] = $this->model('Tarif')->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('kendaraan/edit', $data);
        $this->view('layouts/footer');
    }

    public function update()
    {
        // validasi tarif ada
        $tarif = $this->model('Tarif')->getById($_POST['tarif_id']);
        if (!$tarif) {
            $_SESSION['error'] = "Tarif tidak ditemukan!";
            header('Location: ?url=kendaraan/tambah');
            exit;
        }

        // update kendaraan
        if ($this->kendaraanModel->update($_POST)) {
            $_SESSION['success'] = "Data kendaraan berhasil diubah!";
            logAktivitas($_SESSION['user']['id'], "Mengubah kendaraan: " . $_POST['plat_nomor']);
            header('Location: ?url=kendaraan');
            exit;
        } else {
            $_SESSION['error'] = "Card ID atau Plat Nomor sudah digunakan!";
            header('Location: ?url=kendaraan/edit/' . $_POST['id']);
            exit;
        }
    }

    public function hapus($id)
    {
        // cek apakah kendaraan masih parkir
        $transaksiAktif = $this->model('Transaksi')->getActiveByKendaraan($id);

        if ($transaksiAktif) {
            $_SESSION['error'] = "Kendaraan masih parkir! Tidak bisa dihapus.";
            header('Location: ?url=kendaraan');
            exit;
        }

        // ambil data kendaraan untuk log
        $kendaraan = $this->kendaraanModel->getById($id);
        $plat = $kendaraan['plat_nomor'];

        // hapus kendaraan
        $this->kendaraanModel->delete($id);

        // log aktivitas
        logAktivitas($_SESSION['user']['id'], "Menghapus kendaraan: " . $plat);

        $_SESSION['success'] = "Data kendaraan berhasil dihapus!";
        header('Location: ?url=kendaraan');
        exit;
    }
}
