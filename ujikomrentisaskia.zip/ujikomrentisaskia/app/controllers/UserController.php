<?php
require_once __DIR__ . '/../helpers/LogHelper.php';
class UserController extends Controller
{
    /** @var User $userModel */
    private $userModel;

    public function __construct()
    {
        $this->userModel = $this->model('User');
    }

    // List semua user
    public function index()
    {
        $data['user'] = $this->userModel->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('user/index', $data);
        $this->view('layouts/footer');
    }

    // Halaman tambah user
    public function tambah()
    {
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('user/tambah');
        $this->view('layouts/footer');
    }

    // Simpan user (insert)
    public function simpan()
    {
        if (!$this->userModel->insert($_POST)) {
            $_SESSION['error'] = "Username sudah digunakan!";
            header('Location: ?url=user/tambah');
            exit;
        }

        logAktivitas($_SESSION['user']['id'], "Menambahkan user: " . $_POST['nama_lengkap'] . " (Username: " . $_POST['username'] . ", Role: " . $_POST['role'] . ")"); // Log aktivitas tambah user
        $_SESSION['success'] = "User berhasil ditambahkan!";
        header('Location: ?url=user');
        exit;
    }

    // Halaman edit user
    public function edit($id)
    {
        $data['user'] = $this->userModel->getById($id);
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('user/edit', $data);
        $this->view('layouts/footer');
    }

    // Update user
    public function update()
    {
        if (!$this->userModel->update($_POST)) {
        $_SESSION['error'] = "Username sudah digunakan!";
        header('Location: ?url=user/edit/' . $_POST['id']);
        exit;
    }
        logAktivitas($_SESSION['user']['id'], "Mengubah user: " . $_POST['nama_lengkap'] . " (Username: " . $_POST['username'] . ", Role: " . $_POST['role'] . ")");
        $_SESSION['success'] = "User berhasil diupdate!";
        header('Location: ?url=user');
        exit;
    }

    // Hapus user
    public function hapus($id)
    {
        $user = $this->userModel->getById($id); // ambil data sebelum dihapus

    if ($this->userModel->delete($id)) {

        // log aktivitas
        logAktivitas(
            $_SESSION['user']['id'],
            "Menghapus user: " . $user['nama_lengkap'] . " (Username: " . $user['username'] . ", Role: " . $user['role'] . ")"
        );
        $_SESSION['success'] = "User berhasil dihapus!";
    } else {
        $_SESSION['error'] = "User gagal dihapus!";
    }
    header('Location: ?url=user');
    exit;
    }
}
