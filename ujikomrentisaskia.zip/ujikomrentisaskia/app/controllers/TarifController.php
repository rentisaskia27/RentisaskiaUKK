<?php
require_once __DIR__ . '/../helpers/LogHelper.php';

class TarifController extends Controller
{
    private $tarifModel;

    public function __construct()
    {
        $this->tarifModel = $this->model('Tarif');
    }

    // tampil data tarif
    public function index()
    {
        $data['tarif'] = $this->tarifModel->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('tarif/index', $data);
        $this->view('layouts/footer');
    }

    // halaman tambah
    public function tambah()
    {
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('tarif/tambah');
        $this->view('layouts/footer');
    }

    // simpan tarif
    public function simpan()
    {
        if (!$this->tarifModel->insert($_POST)) {
            $_SESSION['error'] = "Jenis kendaraan sudah ada!";
            header('Location: ?url=tarif/tambah');
            exit;
        }

        logAktivitas($_SESSION['user']['id'], "Menambahkan tarif: " . $_POST['jenis_kendaraan'] . " Rp" . $_POST['tarif_per_jam']);

        header('Location: ?url=tarif');
        exit;
    }

    // halaman edit
    public function edit($id)
    {
        $data['tarif'] = $this->tarifModel->getById($id);
        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('tarif/edit', $data);
        $this->view('layouts/footer');
    }

    // update tarif
    public function update()
    {
        if (!$this->tarifModel->update($_POST)) {
            $_SESSION['error'] = "Jenis kendaraan sudah ada!";
            header('Location: ?url=tarif/edit/' . $_POST['id']);
            exit;
        }

        logAktivitas($_SESSION['user']['id'], "Mengubah tarif: " . $_POST['jenis_kendaraan'] . " menjadi Rp" . $_POST['tarif_per_jam']);
        header('Location: ?url=tarif');
        exit;
    }

    // hapus tarif
    public function hapus($id)
    {
        $tarif = $this->tarifModel->getById($id); // ambil data sebelum dihapus

        if (!$tarif) {
            $_SESSION['error'] = "Tarif tidak ditemukan!";
            header('Location: ?url=tarif');
            exit;
        }

        // Cek apakah ada kendaraan yang menggunakan tarif ini
        $kendaraanTerpakai = $this->tarifModel->kendaraanTerpakai($id);
        if (!empty($kendaraanTerpakai)) {
            $_SESSION['error'] = "Tarif masih digunakan oleh kendaraan!";
            header('Location: ?url=tarif');
            exit;
        }

        // Hapus tarif
        $hapus = $this->tarifModel->delete($id);

        if ($hapus) {
            $_SESSION['success'] = "Tarif (" . $tarif['jenis_kendaraan'] . ") berhasil dihapus.";
            logAktivitas($_SESSION['user']['id'], "Menghapus tarif: " . $tarif['jenis_kendaraan'] . " Rp" . $tarif['tarif_per_jam']);
        } else {
            $_SESSION['error'] = "Gagal menghapus tarif!";
        }

        header('Location: ?url=tarif');
        exit;
    }
}
