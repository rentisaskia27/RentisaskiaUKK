<?php
require_once __DIR__ . '/../helpers/RoleHelper.php';
require_once __DIR__ . '/../helpers/LogHelper.php';
require_once __DIR__ . '/../config/Mqtt.php'; // jika pakai helper MQTT

class TransaksiController extends Controller
{
    private $transaksiModel;
    private $kendaraanModel;
    private $tarifModel;
    private $areaModel;

    public function __construct()
    {
        $this->transaksiModel = $this->model('Transaksi');
        $this->kendaraanModel = $this->model('Kendaraan');
        $this->tarifModel = $this->model('Tarif');
        $this->areaModel = $this->model('Area');

        checkRole(['petugas']);
    }

    // ===================== RIWAYAT =====================
    public function riwayat()
    {
        $limit = 50;

        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

        if ($page < 1) {
            $page = 1;
        }

        $offset = ($page - 1) * $limit;

        if ($offset >= 500) {
            $offset = 450;
            $page = 10;
        }

        $data['transaksi'] = $this->transaksiModel->getRiwayat($limit, $offset);

        $totalData = $this->transaksiModel->countRiwayat();

        $data['totalPage'] = ceil($totalData / $limit);
        $data['currentPage'] = $page;
        $data['startNumber'] = $offset + 1;

        $this->view('layouts/header');
        $this->view('layouts/sidebar_petugas');
        $this->view('transaksi/riwayat', $data);
        $this->view('layouts/footer');
    }

    // ===================== CHECK-IN =====================
    public function masuk()
    {
        $data['kendaraan'] = $this->kendaraanModel->getAll();
        $data['area'] = $this->areaModel->getAll();
        $this->view('layouts/header');
        $this->view('layouts/sidebar_petugas');
        $this->view('transaksi/masuk', $data);
        $this->view('layouts/footer');
    }

    public function simpanMasuk()
    {
        $kendaraan_id = $_POST['kendaraan_id'] ?? null;
        $petugas_id = $_POST['petugas_id'] ?? null;
        $area_id = $_POST['area_id'] ?? null;

        if (!$kendaraan_id || !$area_id || !$petugas_id) {
            $_SESSION['error'] = "Form belum lengkap!";
            header('Location: ?url=transaksi/masuk');
            exit;
        }

        // validasi masih parkir
        $cek = $this->transaksiModel->kendaraanMasihParkir($kendaraan_id);
        if ($cek) {
            $_SESSION['error'] = "Kendaraan masih parkir!";
            header('Location: ?url=transaksi/masuk');
            exit;
        }

        // validasi area penuh
        $area = $this->areaModel->getById($area_id);
        if (!$area || $area['terisi'] >= $area['kapasitas']) {
            $_SESSION['error'] = "Area parkir penuh!";
            header('Location: ?url=transaksi/masuk');
            exit;
        }

        // ambil kendaraan
        $kendaraan = $this->kendaraanModel->getById($kendaraan_id);
        if (!$kendaraan) {
            $_SESSION['error'] = "Kendaraan tidak ditemukan!";
            header('Location: ?url=transaksi/masuk');
            exit;
        }

        // ambil tarif aktif
        $tarif = $this->tarifModel->getByJenisKendaraanAktif($kendaraan['jenis_kendaraan']);
        if (!$tarif) {
            $_SESSION['error'] = "Tarif untuk kendaraan ini tidak tersedia!";
            header('Location: ?url=transaksi/masuk');
            exit;
        }

        // simpan transaksi
        $data = [
            'kendaraan_id' => $kendaraan_id,
            'petugas_id' => $petugas_id,
            'area_id' => $area_id,
            'checkin_time' => date('Y-m-d H:i:s'),
            'tarif_per_jam' => $tarif['tarif_per_jam']
        ];
        $this->transaksiModel->insert($data);

        // update area
        $this->areaModel->incrementTerisi($area_id);

        Mqtt::publish('parking/bismillah/entry/servo', 'OPEN');

        // log aktivitas
        logAktivitas($petugas_id, "Kendaraan masuk: " . $kendaraan['plat_nomor'] . " ke area " . $area['nama_area']);

        $_SESSION['success'] = "Check-in berhasil";
        header('Location: ?url=transaksi/riwayat');
        exit;
    }

    // ===================== CHECK-OUT =====================
    public function keluar($kendaraan_id)
    {
        $transaksi = $this->transaksiModel->getActiveByKendaraan($kendaraan_id);
        if (!$transaksi) {
            $_SESSION['error'] = "Tidak ada transaksi aktif";
            header('Location: ?url=transaksi/riwayat');
            exit;
        }

        $kendaraan = $this->kendaraanModel->getById($kendaraan_id);
        $data['transaksi'] = $transaksi;
        $data['kendaraan'] = $kendaraan;
        $data['tarif'] = ['tarif_per_jam' => $transaksi['tarif_per_jam']];

        $this->view('layouts/header');
        $this->view('layouts/sidebar_petugas');
        $this->view('transaksi/keluar', $data);
        $this->view('layouts/footer');
    }

    public function simpanKeluar()
    {
        $id = $_POST['id'] ?? null;
        if (!$id) {
            $_SESSION['error'] = "Transaksi tidak valid!";
            header('Location: ?url=transaksi/riwayat');
            exit;
        }

        $checkout_time = date('Y-m-d H:i:s');
        $transaksi = $this->transaksiModel->getById($id);
        if (!$transaksi) {
            $_SESSION['error'] = "Transaksi tidak ditemukan!";
            header('Location: ?url=transaksi/riwayat');
            exit;
        }
        if ($transaksi['status'] != 'IN') {
            $_SESSION['error'] = "Kendaraan sudah checkout atau dikonfirmasi!";
            header('Location: ?url=transaksi/riwayat');
            exit;
        }

        $tarif_per_jam = $transaksi['tarif_per_jam'];
        $start = new DateTime($transaksi['checkin_time']);
        $end = new DateTime($checkout_time);
        $diff = $end->diff($start);
        $duration = ($diff->h * 60) + $diff->i;
        if ($duration <= 0) $duration = 1;

        $fee = ceil($duration / 60) * $tarif_per_jam;
        Mqtt::publish('parking/bismillah/exit/lcd', 'Rp ' . number_format($fee, 0, ',', '.'));

        $this->transaksiModel->updateCheckout(
            $id,
            $checkout_time,
            $duration,
            $fee
        );

        $kendaraan = $this->kendaraanModel->getById($transaksi['kendaraan_id']);
        $area = $this->areaModel->getById($transaksi['area_id']);
        logAktivitas($_SESSION['user']['id'], "Kendaraan keluar: " . $kendaraan['plat_nomor'] . " dari area " . $area['nama_area']);

        $_SESSION['success'] = "Checkout berhasil, silahkan konfirmasi pembayaran untuk buka palang";
        header('Location: ?url=transaksi/checkoutList');
        exit;
    }

    // ===================== KONFIRMASI BAYAR / BUKA PALANG =====================
    public function konfirmasi($id)
    {
        $transaksi = $this->transaksiModel->getById($id);
        if (!$transaksi) {
            $_SESSION['error'] = "Transaksi tidak ditemukan";
            header('Location: ?url=transaksi/checkoutList');
            exit;
        }

        if ($transaksi['status'] != 'OUT') {
            $_SESSION['error'] = "Transaksi sudah dikonfirmasi";
            header('Location: ?url=transaksi/checkoutList');
            exit;
        }

        $petugas_id = $_SESSION['user']['id'];

        $this->transaksiModel->konfirmasiCheckout($id, $petugas_id);
        $this->areaModel->decrementTerisi($transaksi['area_id']);

        $kendaraan = $this->kendaraanModel->getById($transaksi['kendaraan_id']);
        $area = $this->areaModel->getById($transaksi['area_id']);

        logAktivitas($petugas_id, "Konfirmasi pembayaran & buka palang untuk kendaraan: " . $kendaraan['plat_nomor'] . " dari area " . $area['nama_area']);

        // tampilkan pesan di LCD
        Mqtt::publish('parking/bismillah/exit/lcd', 'THANKYOU');

        // buka palang
        Mqtt::publish('parking/bismillah/exit/servo', 'OPEN');

        $_SESSION['success'] = "Konfirmasi berhasil, gerbang dibuka";
        header('Location: ?url=transaksi/checkoutList');
        exit;
    }

    // ===================== CETAK STRUK =====================
    public function struk($id)
    {
        $transaksi = $this->transaksiModel->getById($id);
        $kendaraan = $this->kendaraanModel->getById($transaksi['kendaraan_id']);
        $area = $this->areaModel->getById($transaksi['area_id']);

        $data = [
            'transaksi' => $transaksi,
            'kendaraan' => $kendaraan,
            'area' => $area
        ];

        $this->view('transaksi/struk', $data);
    }

    // ===================== LIST CHECKOUT UNTUK PETUGAS =====================
    public function checkoutList()
    {
        $data['transaksi'] = $this->transaksiModel->getAllActive();

        $this->view('layouts/header');
        $this->view('layouts/sidebar_petugas');
        $this->view('transaksi/checkoutList', $data);
        $this->view('layouts/footer');
    }
    
}
