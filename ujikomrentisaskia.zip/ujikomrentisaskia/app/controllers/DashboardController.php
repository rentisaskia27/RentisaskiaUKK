<?php

class DashboardController extends Controller
{
    private $kendaraanModel;
    private $tarifModel;
    private $userModel;
    private $areaModel;

    public function __construct()
    {
        // Batasi akses belum login
        if (!isset($_SESSION['user'])) {
            header('Location: index.php?url=auth/index');
            exit;
        }

        // Inisialisasi model
        $this->kendaraanModel = $this->model('Kendaraan');
        $this->tarifModel = $this->model('Tarif');
        $this->userModel = $this->model('User');
        $this->areaModel = $this->model('Area');
    }

    // Dashboard Admin
    public function admin()
    {
        if ($_SESSION['user']['role'] !== 'admin') {
            echo "Access denied!";
            exit;
        }

        $data = [
            'totalKendaraan' => $this->kendaraanModel->countAll(),
            'totalTarif'     => $this->tarifModel->countAll(),
            'totalUser'      => $this->userModel->countAll(),
            'totalArea'      => $this->areaModel->countAll()
        ];

        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('dashboard/admin', $data);
        $this->view('layouts/footer');
    }

    // Dashboard Petugas
    public function petugas()
    {
        if ($_SESSION['user']['role'] !== 'petugas') {
            echo "Access denied!";
            exit;
        }

        // Load model Transaksi
        $transaksiModel = $this->model('Transaksi');

        $data = [
            'transaksiMasukHariIni'   => $transaksiModel->countMasukHariIni(),
            'transaksiKeluarHariIni'  => $transaksiModel->countKeluarHariIni(),
            'totalTransaksiHariIni'   => $transaksiModel->countTotalHariIni()
        ];

        $this->view('layouts/header');
        $this->view('layouts/sidebar_petugas');
        $this->view('dashboard/petugas', $data);
        $this->view('layouts/footer');
    }

    // Dashboard Owner
    public function owner()
    {
        if ($_SESSION['user']['role'] !== 'owner') {
            echo "Access denied!";
            exit;
        }

        $data = [];

        $this->view('layouts/header');
        $this->view('layouts/sidebar_owner');
        $this->view('dashboard/owner', $data);
        $this->view('layouts/footer');
    }
}
