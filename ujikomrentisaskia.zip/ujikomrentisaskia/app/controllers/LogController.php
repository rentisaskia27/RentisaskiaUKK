<?php
class LogController extends Controller
{
    private $logModel;

    public function __construct()
    {
        $this->logModel = $this->model('LogAktivitas');
    }

    // Halaman list log aktivitas
    public function index()
    {
        $limit = 50;
        $maxData = 500;
        $page = $_GET['page'] ?? 1;
        $page = (int)$page;
        if ($page < 1) $page = 1;
        $offset = ($page - 1) * $limit;
        if ($offset >= $maxData) {
            $offset = $maxData - $limit;
            $page = ceil($maxData / $limit);
        }

        $keyword = $_GET['cari'] ?? '';

        if (!empty($keyword)) {
            $data['log'] = $this->logModel->search($keyword, $limit, $offset);
        } else {
            $data['log'] = $this->logModel->getLimit($limit, $offset);
        }

        $data['currentPage'] = $page;
        $data['totalPage'] = ceil($maxData / $limit);
        $data['keyword'] = $keyword;

        $this->view('layouts/header');
        $this->view('layouts/sidebar_admin');
        $this->view('log/index', $data);
        $this->view('layouts/footer');
    }
}
