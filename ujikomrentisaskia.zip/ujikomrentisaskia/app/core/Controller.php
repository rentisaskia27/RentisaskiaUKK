<?php
class Controller {

    // panggil model
    public function model($model) {
        require_once __DIR__ . '/../models/' . $model . '.php';
        return new $model();
    }

    // panggil view, kirim data ke view
    public function view($view, $data = []) {
        if(!empty($data)) extract($data); // <-- bikin variabel tersedia di view
        require_once __DIR__ . '/../views/' . $view . '.php';
    }
}