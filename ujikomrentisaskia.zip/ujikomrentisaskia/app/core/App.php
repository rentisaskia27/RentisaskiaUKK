<?php
class App
{
    protected $controller = 'AuthController';
    protected $method = 'index';
    protected $params = [];

    public function __construct()
    {
        // Set timezone WIB
        date_default_timezone_set('Asia/Jakarta');

        $url = isset($_GET['url']) ? explode('/', $_GET['url']) : [];

        // Controller
        if (!empty($url[0])) {
            $controllerFile = __DIR__ . '/../controllers/' . ucfirst($url[0]) . 'Controller.php';
            if (file_exists($controllerFile)) {
                require_once $controllerFile;
                $this->controller = ucfirst($url[0]) . 'Controller';
            }
        } else {
            require_once __DIR__ . '/../controllers/' . $this->controller . '.php';
        }

        $this->controller = new $this->controller;

        // Method
        if (isset($url[1])) {
            if (method_exists($this->controller, $url[1])) {
                $this->method = $url[1];
            }
        } else {
            // Kalau POST dari login, paksa ke login
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && method_exists($this->controller, 'login')) {
                $this->method = 'login';
            }
        }

        // Params
        $this->params = $url ? array_values(array_slice($url, 2)) : [];

        $refFunc = new ReflectionMethod($this->controller, $this->method);
        $requiredParams = $refFunc->getNumberOfRequiredParameters();

        if (count($this->params) < $requiredParams) {
            // Kalau kurang parameter, redirect atau set default
            $_SESSION['error'] = "Parameter tidak lengkap";
            header('Location: ?url=transaksi/riwayat'); // redirect ke riwayat
            exit;
        }

        call_user_func_array([$this->controller, $this->method], $this->params);
    }
}
