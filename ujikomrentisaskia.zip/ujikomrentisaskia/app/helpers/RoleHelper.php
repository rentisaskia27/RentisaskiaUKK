<?php
function checkRole($roles = []) {

    if (!isset($_SESSION['user']['role']) ||
        !in_array($_SESSION['user']['role'], $roles)) {

        header('Location: index.php?url=auth/index');
        exit;
    }
}