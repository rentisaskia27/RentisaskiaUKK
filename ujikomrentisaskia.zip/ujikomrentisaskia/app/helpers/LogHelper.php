<?php
require_once __DIR__ . '/../config/Database.php';

function logAktivitas($user_id, $aktivitas) {
    if(!$user_id) {
        die("Error: user_id kosong, log tidak bisa dibuat!");
    }

    $db = Database::getConnection();
    $query = "INSERT INTO log_aktivitas (user_id, aktivitas) VALUES (:user_id, :aktivitas)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':aktivitas', $aktivitas);
    
    try {
        $stmt->execute();
        // Debug sementara
        // echo "Log berhasil dibuat!";
    } catch (PDOException $e) {
        die("Log gagal: " . $e->getMessage());
    }
}
