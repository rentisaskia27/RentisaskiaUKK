<?php

require_once __DIR__ . '/../config/Mqtt.php';

function mqttPublish($topic, $message)
{
    Mqtt::publish($topic, $message);
}