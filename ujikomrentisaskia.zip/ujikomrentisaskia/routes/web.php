<?php
// Routing saat ini ditangani langsung oleh app/core/App.php

?>