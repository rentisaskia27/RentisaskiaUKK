<?php
require_once __DIR__ . '/../app/config/Database.php';

$conn = Database::getConnection();

if($conn){
    echo "Koneksi Database Supabase berhasil!";
}

#BOLEH HAPUS FILE INI, INI CUMA UNTUK TEST KONEKSI DATABASE SAJA