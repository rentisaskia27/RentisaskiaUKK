<?php
date_default_timezone_set('Asia/Jakarta');
session_start();

require_once __DIR__ . '/../app/core/App.php';
require_once __DIR__ . '/../app/core/Controller.php';
require_once __DIR__ . '/../app/core/Model.php';

$app = new App();
