<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

$server = 'broker.hivemq.com';
$port   = 1883;

while (true) {
    try {
        $clientId = 'php_subscriber_' . rand(1000, 9999);

        $connectionSettings = (new ConnectionSettings)
            ->setKeepAliveInterval(60);

        $mqtt = new MqttClient($server, $port, $clientId);
        $mqtt->connect($connectionSettings, true);

        echo "MQTT connected" . PHP_EOL;

        // RFID ENTRY
        $mqtt->subscribe('parking/bismillah/entry/rfid', function ($topic, $message) {
            $card_id = trim($message);

            echo "RFID Entry: $card_id" . PHP_EOL;

            $url = "http://localhost/ujikomrentisaskia/public/api/checkin.php?card_id=" . urlencode($card_id);
            $result = @file_get_contents($url);

            if ($result !== false) {
                echo "Checkin diproses" . PHP_EOL;
            } else {
                echo "Checkin gagal" . PHP_EOL;
            }
        }, 0);

        // RFID EXIT
        $mqtt->subscribe('parking/bismillah/exit/rfid', function ($topic, $message) {
            $card_id = trim($message);

            echo "RFID Exit: $card_id" . PHP_EOL;

            $url = "http://localhost/ujikomrentisaskia/public/api/checkout.php?card_id=" . urlencode($card_id);
            $result = @file_get_contents($url);

            if ($result !== false) {
                echo "Checkout diproses" . PHP_EOL;
            } else {
                echo "Checkout gagal" . PHP_EOL;
            }
        }, 0);

        $mqtt->loop(true);
    } catch (\Throwable $e) {
        echo "MQTT reconnect..." . PHP_EOL;
        sleep(2);
    }
}