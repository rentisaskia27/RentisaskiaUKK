<?php
// publish pesan ke MQTT broker

require_once __DIR__ . '/../../app/config/Mqtt.php';

// Ambil data dari request
$topic   = $_GET['topic'] ?? null;
$message = $_GET['message'] ?? null;

// Validasi
if (!$topic || !$message) {
    http_response_code(400); // Bad Request
    echo json_encode([
        'status' => 'error',
        'message' => 'Topic atau message kosong'
    ]);
    exit;
}

// Kirim ke MQTT
try {
    Mqtt::publish($topic, $message);
    echo json_encode([
        'status' => 'success',
        'message' => 'Pesan berhasil dikirim'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal kirim pesan: ' . $e->getMessage()
    ]);
}