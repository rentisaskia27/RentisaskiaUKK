<?php
date_default_timezone_set('Asia/Jakarta');

session_start();
require_once __DIR__ . '/../../app/core/Model.php';
require_once __DIR__ . '/../../app/models/Kendaraan.php';
require_once __DIR__ . '/../../app/models/Area.php';
require_once __DIR__ . '/../../app/models/Transaksi.php';
require_once __DIR__ . '/../../app/models/Tarif.php';
require_once __DIR__ . '/../../app/helpers/MqttHelper.php';
require_once __DIR__ . '/../../app/helpers/LogHelper.php';

// Ambil input (RFID atau plat nomor manual)
$card_id = $_GET['card_id'] ?? $_POST['card_id'] ?? null;
$plat_nomor = $_POST['plat_nomor'] ?? null;
$petugas_id = 2;

if (!$petugas_id) {
    echo json_encode(['status' => 'error', 'message' => 'Petugas tidak terdeteksi']);
    exit;
}

$kendaraanModel = new Kendaraan();
$areaModel      = new Area();
$transaksiModel = new Transaksi();
$tarifModel     = new Tarif();

// ==================== Ambil Kendaraan ====================
if ($card_id) {
    $kendaraan = $kendaraanModel->getByCardId($card_id);
} elseif ($plat_nomor) {
    $kendaraan = $kendaraanModel->getByPlat($plat_nomor);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Kendaraan tidak terdeteksi']);
    exit;
}

if (!$kendaraan) {
    echo json_encode(['status' => 'error', 'message' => 'Kendaraan tidak ditemukan']);
    exit;
}

// Cek apakah kendaraan masih parkir
if ($transaksiModel->kendaraanMasihParkir($kendaraan['id'])) {

    mqttPublish("parking/bismillah/entry/lcd", "ALREADY");

    echo json_encode(['status' => 'error', 'message' => 'Kendaraan masih parkir']);
    exit;
}

// ==================== Ambil Area ====================
$area = $areaModel->getAvailable();
if (!$area) {
    echo json_encode(['status' => 'error', 'message' => 'Parkiran penuh']);
    exit;
}

// ==================== Ambil Tarif ====================
$tarif = $tarifModel->getByJenisKendaraanAktif($kendaraan['jenis_kendaraan']);
if (!$tarif) {
    echo json_encode(['status' => 'error', 'message' => 'Tarif kendaraan tidak tersedia']);
    exit;
}

// ==================== Simpan Transaksi ====================
$data = [
    'kendaraan_id' => $kendaraan['id'],
    'petugas_id'   => $petugas_id,
    'area_id'      => $area['id'],
    'checkin_time' => date('Y-m-d H:i:s'),
    'tarif_per_jam' => $tarif['tarif_per_jam']
];

$transaksiModel->insert($data);

// Update area
$areaModel->incrementTerisi($area['id']);

// Log aktivitas
logAktivitas($petugas_id, "Kendaraan masuk: {$kendaraan['plat_nomor']} ke area {$area['nama_area']}");

// ==================== MQTT ====================

mqttPublish("parking/bismillah/entry/lcd", "WELCOME");

mqttPublish("parking/bismillah/entry/servo", "OPEN");

// ==================== Response ====================
echo json_encode([
    'status' => 'success',
    'message' => 'Check-in berhasil',
    'data'   => [
        'kendaraan' => $kendaraan,
        'area'      => $area,
        'checkin_time' => $data['checkin_time']
    ]
]);
