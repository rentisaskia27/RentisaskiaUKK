<?php
date_default_timezone_set('Asia/Jakarta');

session_start();
require_once __DIR__ . '/../../app/core/Model.php';
require_once __DIR__ . '/../../app/models/Kendaraan.php';
require_once __DIR__ . '/../../app/models/Area.php';
require_once __DIR__ . '/../../app/models/Transaksi.php';
require_once __DIR__ . '/../../app/helpers/MqttHelper.php';
require_once __DIR__ . '/../../app/helpers/LogHelper.php';

// Ambil input (RFID atau plat nomor manual)
$card_id    = $_GET['card_id'] ?? $_POST['card_id'] ?? null;
$plat_nomor = $_POST['plat_nomor'] ?? null;

$kendaraanModel = new Kendaraan();
$areaModel      = new Area();
$transaksiModel = new Transaksi();

// ==================== Ambil Kendaraan ====================
if ($card_id) {
    $kendaraan = $kendaraanModel->getByCardId($card_id);
} elseif ($plat_nomor) {
    $kendaraan = $kendaraanModel->getByPlat($plat_nomor);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Kendaraan tidak terdeteksi']);
    exit;
}

if (!$kendaraan) {
    echo json_encode(['status' => 'error', 'message' => 'Kendaraan tidak ditemukan']);
    exit;
}

// ==================== Ambil Transaksi Aktif ====================
$transaksi = $transaksiModel->getActiveByKendaraan($kendaraan['id']);
if (!$transaksi) {

    mqttPublish("parking/bismillah/exit/lcd", "DONE");

    echo json_encode([
        'status' => 'error',
        'message' => 'Transaksi aktif tidak ditemukan'
    ]);
    exit;
}

// ==================== Hitung Durasi & Biaya ====================
$checkout_time = date('Y-m-d H:i:s');
$start = new DateTime($transaksi['checkin_time']);
$end   = new DateTime($checkout_time);
$diff  = $end->diff($start);

$duration_minutes = ($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i;
if ($duration_minutes <= 0) $duration_minutes = 1;

// Hitung biaya
$tarif_per_jam = $transaksi['tarif_per_jam'];
$fee = ceil($duration_minutes / 60) * $tarif_per_jam;

// Update transaksi jadi OUT
$transaksiModel->updateCheckout(
    $transaksi['id'],
    $checkout_time,
    $duration_minutes,
    $fee
);

// Ambil area
$area = $areaModel->getById($transaksi['area_id']);

// ==================== MQTT ====================
// LCD Exit
mqttPublish("parking/bismillah/exit/lcd", "Rp " . number_format($fee, 0, ',', '.'));

echo json_encode([
    'status' => 'success',
    'message' => 'Checkout berhasil, tunggu konfirmasi pembayaran',
    'data'   => [
        'kendaraan'     => $kendaraan,
        'area'          => $area,
        'checkin_time'  => $transaksi['checkin_time'],
        'checkout_time' => $checkout_time,
        'duration'      => $duration_minutes,
        'fee'           => $fee
    ]
]);
