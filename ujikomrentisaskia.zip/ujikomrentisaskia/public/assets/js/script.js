document.addEventListener("DOMContentLoaded", function () {

    // klik buka tutup
    document.querySelectorAll('.menu-toggle').forEach(menu => {

        menu.addEventListener('click', function(e) {

            e.preventDefault();

            let parent = this.parentElement;

            document.querySelectorAll('.menu-item').forEach(item => {
                if (item !== parent) {
                    item.classList.remove('open');
                }
            });

            parent.classList.toggle('open');

        });

    });

    // auto open saat active
    document.querySelectorAll('.submenu a.active').forEach(activeMenu => {

        let parent = activeMenu.closest('.menu-item');

        if (parent) {
            parent.classList.add('open');
        }

    });

});