<?php
require_once __DIR__ . '/../app/models/Kendaraan.php';

$kendaraan = new Kendaraan();

// Test getAll
$data = $kendaraan->getAll();
echo "<pre>";
print_r($data);
echo "</pre>";